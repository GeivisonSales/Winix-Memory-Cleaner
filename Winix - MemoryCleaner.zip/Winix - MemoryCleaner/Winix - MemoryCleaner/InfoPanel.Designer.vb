﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class InfoPanel
    Inherits System.Windows.Forms.UserControl

    'UserControl overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.buttonUpdate = New System.Windows.Forms.PictureBox()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.lblversion = New System.Windows.Forms.Label()
        Me.giftbutton = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.giftpanel = New System.Windows.Forms.Panel()
        Me.FlowLayoutPanel1 = New System.Windows.Forms.FlowLayoutPanel()
        Me.giftcodetextbox = New Winix___MemoryCleaner.WinixTHEMENormalTextBox()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.buttonUpdate, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.giftpanel.SuspendLayout()
        Me.FlowLayoutPanel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.Winix___MemoryCleaner.My.Resources.Resources.UI_WMC_LOGO_2019
        Me.PictureBox1.Location = New System.Drawing.Point(154, 38)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(129, 120)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox1.TabIndex = 0
        Me.PictureBox1.TabStop = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Segoe UI", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel)
        Me.Label1.ForeColor = System.Drawing.Color.White
        Me.Label1.Location = New System.Drawing.Point(120, 161)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(197, 25)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "Winix - MemoryCleaner"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Segoe UI", 11.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel)
        Me.Label2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(105, Byte), Integer), CType(CType(108, Byte), Integer), CType(CType(135, Byte), Integer))
        Me.Label2.Location = New System.Drawing.Point(125, 193)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(187, 52)
        Me.Label2.TabIndex = 3
        Me.Label2.Text = "This program was created and" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "developed by WINIXCOMPANY," & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "design created by WINIX" &
    "GRAPHICS." & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Release Date: 2018"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'PictureBox2
        '
        Me.PictureBox2.Image = Global.Winix___MemoryCleaner.My.Resources.Resources.LOGOWINIX_2017__FLAT_WHITE_
        Me.PictureBox2.Location = New System.Drawing.Point(211, 249)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(15, 15)
        Me.PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox2.TabIndex = 4
        Me.PictureBox2.TabStop = False
        '
        'buttonUpdate
        '
        Me.buttonUpdate.Cursor = System.Windows.Forms.Cursors.Hand
        Me.buttonUpdate.Image = Global.Winix___MemoryCleaner.My.Resources.Resources.ButtonCheckUpdate
        Me.buttonUpdate.Location = New System.Drawing.Point(3, 72)
        Me.buttonUpdate.Name = "buttonUpdate"
        Me.buttonUpdate.Size = New System.Drawing.Size(170, 46)
        Me.buttonUpdate.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.buttonUpdate.TabIndex = 5
        Me.buttonUpdate.TabStop = False
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.Panel2.Location = New System.Drawing.Point(108, 419)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(221, 1)
        Me.Panel2.TabIndex = 2
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel)
        Me.Label3.ForeColor = System.Drawing.Color.FromArgb(CType(CType(105, Byte), Integer), CType(CType(108, Byte), Integer), CType(CType(135, Byte), Integer))
        Me.Label3.Location = New System.Drawing.Point(163, 425)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(126, 26)
        Me.Label3.TabIndex = 6
        Me.Label3.Text = "ALL RIGHTS RESERVED" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Copyright © 2019"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblversion
        '
        Me.lblversion.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblversion.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel)
        Me.lblversion.ForeColor = System.Drawing.Color.FromArgb(CType(CType(105, Byte), Integer), CType(CType(108, Byte), Integer), CType(CType(135, Byte), Integer))
        Me.lblversion.Location = New System.Drawing.Point(132, 393)
        Me.lblversion.Name = "lblversion"
        Me.lblversion.Size = New System.Drawing.Size(172, 17)
        Me.lblversion.TabIndex = 7
        Me.lblversion.Text = "v0.0 (Build 0. 0)"
        Me.lblversion.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'giftbutton
        '
        Me.giftbutton.Enabled = False
        Me.giftbutton.FlatAppearance.BorderColor = System.Drawing.Color.White
        Me.giftbutton.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(13, Byte), Integer), CType(CType(58, Byte), Integer))
        Me.giftbutton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gray
        Me.giftbutton.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.giftbutton.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.giftbutton.ForeColor = System.Drawing.Color.White
        Me.giftbutton.Location = New System.Drawing.Point(149, 0)
        Me.giftbutton.Name = "giftbutton"
        Me.giftbutton.Size = New System.Drawing.Size(21, 26)
        Me.giftbutton.TabIndex = 9
        Me.giftbutton.Text = ">"
        Me.giftbutton.UseVisualStyleBackColor = True
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.FromArgb(CType(CType(105, Byte), Integer), CType(CType(108, Byte), Integer), CType(CType(135, Byte), Integer))
        Me.Button1.Cursor = System.Windows.Forms.Cursors.Help
        Me.Button1.FlatAppearance.BorderSize = 0
        Me.Button1.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(105, Byte), Integer), CType(CType(108, Byte), Integer), CType(CType(135, Byte), Integer))
        Me.Button1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(1, Byte), Integer), CType(CType(3, Byte), Integer), CType(CType(47, Byte), Integer))
        Me.Button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button1.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.Button1.ForeColor = System.Drawing.Color.White
        Me.Button1.Location = New System.Drawing.Point(3, 41)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(170, 25)
        Me.Button1.TabIndex = 10
        Me.Button1.Text = "Bugs? Inform us!"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'giftpanel
        '
        Me.giftpanel.Controls.Add(Me.giftcodetextbox)
        Me.giftpanel.Controls.Add(Me.giftbutton)
        Me.giftpanel.Location = New System.Drawing.Point(3, 3)
        Me.giftpanel.Name = "giftpanel"
        Me.giftpanel.Size = New System.Drawing.Size(176, 32)
        Me.giftpanel.TabIndex = 11
        '
        'FlowLayoutPanel1
        '
        Me.FlowLayoutPanel1.AutoSize = True
        Me.FlowLayoutPanel1.Controls.Add(Me.giftpanel)
        Me.FlowLayoutPanel1.Controls.Add(Me.Button1)
        Me.FlowLayoutPanel1.Controls.Add(Me.buttonUpdate)
        Me.FlowLayoutPanel1.FlowDirection = System.Windows.Forms.FlowDirection.TopDown
        Me.FlowLayoutPanel1.Location = New System.Drawing.Point(130, 268)
        Me.FlowLayoutPanel1.Name = "FlowLayoutPanel1"
        Me.FlowLayoutPanel1.Size = New System.Drawing.Size(188, 124)
        Me.FlowLayoutPanel1.TabIndex = 12
        '
        'giftcodetextbox
        '
        Me.giftcodetextbox.BackColor = System.Drawing.Color.Transparent
        Me.giftcodetextbox.BackgroundColour = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(13, Byte), Integer), CType(CType(58, Byte), Integer))
        Me.giftcodetextbox.BorderColour = System.Drawing.Color.Silver
        Me.giftcodetextbox.Font = New System.Drawing.Font("Segoe UI", 8.25!)
        Me.giftcodetextbox.Location = New System.Drawing.Point(0, 0)
        Me.giftcodetextbox.MaxLength = 14
        Me.giftcodetextbox.Multiline = False
        Me.giftcodetextbox.Name = "giftcodetextbox"
        Me.giftcodetextbox.ReadOnly = False
        Me.giftcodetextbox.Size = New System.Drawing.Size(150, 26)
        Me.giftcodetextbox.Style = Winix___MemoryCleaner.WinixTHEMENormalTextBox.Styles.NotRounded
        Me.giftcodetextbox.TabIndex = 8
        Me.giftcodetextbox.Text = "YOUR GIFT CODE"
        Me.giftcodetextbox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.giftcodetextbox.TextColour = System.Drawing.Color.Silver
        Me.giftcodetextbox.UseSystemPasswordChar = False
        '
        'InfoPanel
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(13, Byte), Integer), CType(CType(58, Byte), Integer))
        Me.Controls.Add(Me.FlowLayoutPanel1)
        Me.Controls.Add(Me.lblversion)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.PictureBox2)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.PictureBox1)
        Me.Name = "InfoPanel"
        Me.Size = New System.Drawing.Size(434, 473)
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.buttonUpdate, System.ComponentModel.ISupportInitialize).EndInit()
        Me.giftpanel.ResumeLayout(False)
        Me.FlowLayoutPanel1.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents buttonUpdate As PictureBox
    Friend WithEvents Panel2 As Panel
    Friend WithEvents Label3 As Label
    Friend WithEvents lblversion As Label
    Friend WithEvents giftbutton As Button
    Public WithEvents giftcodetextbox As WinixTHEMENormalTextBox
    Friend WithEvents Button1 As Button
    Friend WithEvents giftpanel As Panel
    Friend WithEvents FlowLayoutPanel1 As FlowLayoutPanel
End Class
