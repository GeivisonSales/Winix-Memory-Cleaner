﻿Public Class BETA_VIEW_PANEL
    Private Sub NotificationBetaView_Click(sender As Object, e As EventArgs) Handles NotificationBetaView.Click
        NotificationBetaView.Visible = False
    End Sub
End Class
