﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class formconfig
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(formconfig))
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.bandBRAZIL = New System.Windows.Forms.Button()
        Me.bandUSA = New System.Windows.Forms.Button()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.lblversion = New System.Windows.Forms.Label()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.chk1 = New Winix___MemoryCleaner.WinixTHEMECheckBox()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.chk2 = New Winix___MemoryCleaner.WinixTHEMECheckBox()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.chk3 = New Winix___MemoryCleaner.WinixTHEMECheckBox()
        Me.chk4 = New Winix___MemoryCleaner.WinixTHEMECheckBox()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.chk5 = New Winix___MemoryCleaner.WinixTHEMECheckBox()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.Panel1.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.Panel3.SuspendLayout()
        Me.Panel4.SuspendLayout()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.FromArgb(CType(CType(1, Byte), Integer), CType(CType(3, Byte), Integer), CType(CType(47, Byte), Integer))
        Me.Panel1.Controls.Add(Me.bandBRAZIL)
        Me.Panel1.Controls.Add(Me.bandUSA)
        Me.Panel1.Controls.Add(Me.Label2)
        Me.Panel1.Controls.Add(Me.Button3)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(296, 32)
        Me.Panel1.TabIndex = 5
        '
        'bandBRAZIL
        '
        Me.bandBRAZIL.BackColor = System.Drawing.Color.FromArgb(CType(CType(1, Byte), Integer), CType(CType(3, Byte), Integer), CType(CType(47, Byte), Integer))
        Me.bandBRAZIL.BackgroundImage = Global.Winix___MemoryCleaner.My.Resources.Resources.band_brazil
        Me.bandBRAZIL.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.bandBRAZIL.Cursor = System.Windows.Forms.Cursors.Hand
        Me.bandBRAZIL.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(1, Byte), Integer), CType(CType(3, Byte), Integer), CType(CType(47, Byte), Integer))
        Me.bandBRAZIL.FlatAppearance.BorderSize = 0
        Me.bandBRAZIL.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.bandBRAZIL.Font = New System.Drawing.Font("Century Gothic", 9.75!)
        Me.bandBRAZIL.ForeColor = System.Drawing.Color.White
        Me.bandBRAZIL.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.bandBRAZIL.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.bandBRAZIL.Location = New System.Drawing.Point(226, 4)
        Me.bandBRAZIL.Name = "bandBRAZIL"
        Me.bandBRAZIL.Size = New System.Drawing.Size(32, 22)
        Me.bandBRAZIL.TabIndex = 18
        Me.bandBRAZIL.UseVisualStyleBackColor = False
        Me.bandBRAZIL.Visible = False
        '
        'bandUSA
        '
        Me.bandUSA.BackColor = System.Drawing.Color.FromArgb(CType(CType(231, Byte), Integer), CType(CType(76, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.bandUSA.BackgroundImage = Global.Winix___MemoryCleaner.My.Resources.Resources.band_USA
        Me.bandUSA.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.bandUSA.Cursor = System.Windows.Forms.Cursors.Hand
        Me.bandUSA.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(1, Byte), Integer), CType(CType(3, Byte), Integer), CType(CType(47, Byte), Integer))
        Me.bandUSA.FlatAppearance.BorderSize = 0
        Me.bandUSA.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.bandUSA.Font = New System.Drawing.Font("Century Gothic", 9.75!)
        Me.bandUSA.ForeColor = System.Drawing.Color.White
        Me.bandUSA.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.bandUSA.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.bandUSA.Location = New System.Drawing.Point(194, 4)
        Me.bandUSA.Name = "bandUSA"
        Me.bandUSA.Size = New System.Drawing.Size(32, 22)
        Me.bandUSA.TabIndex = 17
        Me.bandUSA.UseVisualStyleBackColor = False
        Me.bandUSA.Visible = False
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Century Gothic", 10.0!)
        Me.Label2.ForeColor = System.Drawing.Color.White
        Me.Label2.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label2.Location = New System.Drawing.Point(8, 6)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(170, 19)
        Me.Label2.TabIndex = 15
        Me.Label2.Text = "Winix - MemoryCleaner"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Button3
        '
        Me.Button3.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(13, Byte), Integer), CType(CType(58, Byte), Integer))
        Me.Button3.BackgroundImage = Global.Winix___MemoryCleaner.My.Resources.Resources.close
        Me.Button3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.Button3.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Button3.Dock = System.Windows.Forms.DockStyle.Right
        Me.Button3.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(1, Byte), Integer), CType(CType(3, Byte), Integer), CType(CType(47, Byte), Integer))
        Me.Button3.FlatAppearance.BorderSize = 0
        Me.Button3.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(1, Byte), Integer), CType(CType(3, Byte), Integer), CType(CType(47, Byte), Integer))
        Me.Button3.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(13, Byte), Integer), CType(CType(58, Byte), Integer))
        Me.Button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button3.Font = New System.Drawing.Font("Century Gothic", 9.75!)
        Me.Button3.ForeColor = System.Drawing.Color.White
        Me.Button3.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button3.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Button3.Location = New System.Drawing.Point(266, 0)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(30, 32)
        Me.Button3.TabIndex = 14
        Me.Button3.UseVisualStyleBackColor = False
        '
        'lblversion
        '
        Me.lblversion.AutoSize = True
        Me.lblversion.Dock = System.Windows.Forms.DockStyle.Left
        Me.lblversion.Font = New System.Drawing.Font("Century Gothic", 8.0!)
        Me.lblversion.ForeColor = System.Drawing.Color.White
        Me.lblversion.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblversion.Location = New System.Drawing.Point(0, 0)
        Me.lblversion.Name = "lblversion"
        Me.lblversion.Size = New System.Drawing.Size(19, 16)
        Me.lblversion.TabIndex = 15
        Me.lblversion.Text = "v."
        Me.lblversion.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.chk1)
        Me.GroupBox1.Controls.Add(Me.Panel2)
        Me.GroupBox1.Font = New System.Drawing.Font("Century Gothic", 9.0!)
        Me.GroupBox1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(231, Byte), Integer), CType(CType(76, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.GroupBox1.Location = New System.Drawing.Point(10, 32)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(277, 88)
        Me.GroupBox1.TabIndex = 7
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "MemoryCleaner"
        '
        'chk1
        '
        Me.chk1.BaseColour = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(13, Byte), Integer), CType(CType(58, Byte), Integer))
        Me.chk1.BorderColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.chk1.Checked = True
        Me.chk1.CheckedColour = System.Drawing.Color.FromArgb(CType(CType(231, Byte), Integer), CType(CType(76, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.chk1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.chk1.FontColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.chk1.Location = New System.Drawing.Point(17, 24)
        Me.chk1.Name = "chk1"
        Me.chk1.Size = New System.Drawing.Size(234, 22)
        Me.chk1.TabIndex = 25
        Me.chk1.Text = "Refresh the CPU every 1 minute."
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.FromArgb(CType(CType(231, Byte), Integer), CType(CType(76, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.Panel2.Controls.Add(Me.chk2)
        Me.Panel2.Cursor = System.Windows.Forms.Cursors.No
        Me.Panel2.Location = New System.Drawing.Point(5, 49)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(188, 28)
        Me.Panel2.TabIndex = 9
        '
        'chk2
        '
        Me.chk2.BaseColour = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(13, Byte), Integer), CType(CType(58, Byte), Integer))
        Me.chk2.BorderColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.chk2.Checked = False
        Me.chk2.CheckedColour = System.Drawing.Color.FromArgb(CType(CType(231, Byte), Integer), CType(CType(76, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.chk2.Cursor = System.Windows.Forms.Cursors.Hand
        Me.chk2.Enabled = False
        Me.chk2.FontColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.chk2.Location = New System.Drawing.Point(2, 4)
        Me.chk2.Name = "chk2"
        Me.chk2.Size = New System.Drawing.Size(184, 22)
        Me.chk2.TabIndex = 26
        Me.chk2.Text = "Decrease CPU usage by 2x."
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.chk3)
        Me.GroupBox2.Controls.Add(Me.chk4)
        Me.GroupBox2.Controls.Add(Me.Panel3)
        Me.GroupBox2.Font = New System.Drawing.Font("Century Gothic", 9.0!)
        Me.GroupBox2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(231, Byte), Integer), CType(CType(76, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.GroupBox2.Location = New System.Drawing.Point(10, 125)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(277, 120)
        Me.GroupBox2.TabIndex = 8
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "MemoryCleaner - TAB"
        '
        'chk3
        '
        Me.chk3.BaseColour = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(13, Byte), Integer), CType(CType(58, Byte), Integer))
        Me.chk3.BorderColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.chk3.Checked = False
        Me.chk3.CheckedColour = System.Drawing.Color.FromArgb(CType(CType(231, Byte), Integer), CType(CType(76, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.chk3.Cursor = System.Windows.Forms.Cursors.Hand
        Me.chk3.FontColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.chk3.Location = New System.Drawing.Point(17, 24)
        Me.chk3.Name = "chk3"
        Me.chk3.Size = New System.Drawing.Size(239, 22)
        Me.chk3.TabIndex = 27
        Me.chk3.Text = "Keep the window always in front."
        '
        'chk4
        '
        Me.chk4.BaseColour = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(13, Byte), Integer), CType(CType(58, Byte), Integer))
        Me.chk4.BorderColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.chk4.Checked = True
        Me.chk4.CheckedColour = System.Drawing.Color.FromArgb(CType(CType(231, Byte), Integer), CType(CType(76, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.chk4.Cursor = System.Windows.Forms.Cursors.Hand
        Me.chk4.FontColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.chk4.Location = New System.Drawing.Point(17, 51)
        Me.chk4.Name = "chk4"
        Me.chk4.Size = New System.Drawing.Size(196, 22)
        Me.chk4.TabIndex = 28
        Me.chk4.Text = "Always allow open window."
        '
        'Panel3
        '
        Me.Panel3.BackColor = System.Drawing.Color.FromArgb(CType(CType(231, Byte), Integer), CType(CType(76, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.Panel3.Controls.Add(Me.chk5)
        Me.Panel3.Cursor = System.Windows.Forms.Cursors.No
        Me.Panel3.Location = New System.Drawing.Point(5, 79)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(259, 28)
        Me.Panel3.TabIndex = 10
        '
        'chk5
        '
        Me.chk5.BaseColour = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(13, Byte), Integer), CType(CType(58, Byte), Integer))
        Me.chk5.BorderColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.chk5.Checked = False
        Me.chk5.CheckedColour = System.Drawing.Color.FromArgb(CType(CType(231, Byte), Integer), CType(CType(76, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.chk5.Cursor = System.Windows.Forms.Cursors.Hand
        Me.chk5.Enabled = False
        Me.chk5.FontColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.chk5.Location = New System.Drawing.Point(3, 4)
        Me.chk5.Name = "chk5"
        Me.chk5.Size = New System.Drawing.Size(256, 22)
        Me.chk5.TabIndex = 29
        Me.chk5.Text = "Allow show button to reload processes."
        '
        'Panel4
        '
        Me.Panel4.Controls.Add(Me.lblversion)
        Me.Panel4.Location = New System.Drawing.Point(9, 253)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(251, 21)
        Me.Panel4.TabIndex = 13
        '
        'formconfig
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(13, Byte), Integer), CType(CType(58, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(296, 277)
        Me.Controls.Add(Me.Panel4)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.Panel1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "formconfig"
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Winix - MemoryCleaner"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.Panel2.ResumeLayout(False)
        Me.GroupBox2.ResumeLayout(False)
        Me.Panel3.ResumeLayout(False)
        Me.Panel4.ResumeLayout(False)
        Me.Panel4.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Panel1 As Panel
    Friend WithEvents Button3 As Button
    Friend WithEvents lblversion As Label
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents Panel2 As Panel
    Friend WithEvents Panel3 As Panel
    Friend WithEvents Label2 As Label
    Friend WithEvents Panel4 As Panel
    Friend WithEvents chk1 As WinixTHEMECheckBox
    Friend WithEvents chk2 As WinixTHEMECheckBox
    Friend WithEvents chk3 As WinixTHEMECheckBox
    Friend WithEvents chk4 As WinixTHEMECheckBox
    Friend WithEvents chk5 As WinixTHEMECheckBox
    Friend WithEvents bandUSA As Button
    Friend WithEvents bandBRAZIL As Button
End Class
