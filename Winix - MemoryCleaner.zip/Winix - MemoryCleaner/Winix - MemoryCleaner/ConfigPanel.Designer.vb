﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class ConfigPanel
    Inherits System.Windows.Forms.UserControl

    'UserControl overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.chk5 = New Winix___MemoryCleaner.WinixTHEMECheckBox()
        Me.PanelRam = New System.Windows.Forms.Panel()
        Me.chk2 = New Winix___MemoryCleaner.WinixTHEMECheckBox()
        Me.chk1 = New Winix___MemoryCleaner.WinixTHEMECheckBox()
        Me.LabelRam = New System.Windows.Forms.Label()
        Me.PanelRamLine = New System.Windows.Forms.Panel()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.chk3 = New Winix___MemoryCleaner.WinixTHEMECheckBox()
        Me.chk4 = New Winix___MemoryCleaner.WinixTHEMECheckBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Panel5 = New System.Windows.Forms.Panel()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Panel3.SuspendLayout()
        Me.PanelRam.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Panel3
        '
        Me.Panel3.BackColor = System.Drawing.Color.FromArgb(CType(CType(231, Byte), Integer), CType(CType(76, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.Panel3.Controls.Add(Me.chk5)
        Me.Panel3.Cursor = System.Windows.Forms.Cursors.No
        Me.Panel3.Location = New System.Drawing.Point(14, 99)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(259, 28)
        Me.Panel3.TabIndex = 10
        '
        'chk5
        '
        Me.chk5.BaseColour = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(13, Byte), Integer), CType(CType(58, Byte), Integer))
        Me.chk5.BorderColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.chk5.Checked = False
        Me.chk5.CheckedColour = System.Drawing.Color.FromArgb(CType(CType(231, Byte), Integer), CType(CType(76, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.chk5.Cursor = System.Windows.Forms.Cursors.Hand
        Me.chk5.Enabled = False
        Me.chk5.Font = New System.Drawing.Font("Segoe UI", 8.25!)
        Me.chk5.FontColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.chk5.Location = New System.Drawing.Point(3, 4)
        Me.chk5.Name = "chk5"
        Me.chk5.Size = New System.Drawing.Size(256, 22)
        Me.chk5.TabIndex = 29
        Me.chk5.Text = "Allow show button to reload processes."
        '
        'PanelRam
        '
        Me.PanelRam.BackColor = System.Drawing.Color.FromArgb(CType(CType(1, Byte), Integer), CType(CType(3, Byte), Integer), CType(CType(47, Byte), Integer))
        Me.PanelRam.Controls.Add(Me.chk2)
        Me.PanelRam.Controls.Add(Me.chk1)
        Me.PanelRam.Controls.Add(Me.LabelRam)
        Me.PanelRam.Controls.Add(Me.PanelRamLine)
        Me.PanelRam.Location = New System.Drawing.Point(51, 53)
        Me.PanelRam.Name = "PanelRam"
        Me.PanelRam.Size = New System.Drawing.Size(324, 131)
        Me.PanelRam.TabIndex = 11
        '
        'chk2
        '
        Me.chk2.BaseColour = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(13, Byte), Integer), CType(CType(58, Byte), Integer))
        Me.chk2.BorderColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.chk2.Checked = False
        Me.chk2.CheckedColour = System.Drawing.Color.FromArgb(CType(CType(231, Byte), Integer), CType(CType(76, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.chk2.Cursor = System.Windows.Forms.Cursors.Hand
        Me.chk2.Font = New System.Drawing.Font("Segoe UI", 8.25!)
        Me.chk2.FontColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.chk2.Location = New System.Drawing.Point(14, 74)
        Me.chk2.Name = "chk2"
        Me.chk2.Size = New System.Drawing.Size(184, 22)
        Me.chk2.TabIndex = 26
        Me.chk2.Text = "Using GiftCode (info)"
        '
        'chk1
        '
        Me.chk1.BaseColour = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(13, Byte), Integer), CType(CType(58, Byte), Integer))
        Me.chk1.BorderColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.chk1.Checked = True
        Me.chk1.CheckedColour = System.Drawing.Color.FromArgb(CType(CType(231, Byte), Integer), CType(CType(76, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.chk1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.chk1.Font = New System.Drawing.Font("Segoe UI", 8.25!)
        Me.chk1.FontColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.chk1.Location = New System.Drawing.Point(14, 47)
        Me.chk1.Name = "chk1"
        Me.chk1.Size = New System.Drawing.Size(234, 22)
        Me.chk1.TabIndex = 25
        Me.chk1.Text = "Refresh the CPU every 1 minute."
        '
        'LabelRam
        '
        Me.LabelRam.AutoSize = True
        Me.LabelRam.Font = New System.Drawing.Font("Microsoft Sans Serif", 17.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel)
        Me.LabelRam.ForeColor = System.Drawing.Color.White
        Me.LabelRam.Location = New System.Drawing.Point(10, 7)
        Me.LabelRam.Name = "LabelRam"
        Me.LabelRam.Size = New System.Drawing.Size(181, 20)
        Me.LabelRam.TabIndex = 2
        Me.LabelRam.Text = "MEMORY CLEANER"
        Me.LabelRam.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'PanelRamLine
        '
        Me.PanelRamLine.BackColor = System.Drawing.Color.DarkGray
        Me.PanelRamLine.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.PanelRamLine.Location = New System.Drawing.Point(0, 126)
        Me.PanelRamLine.Name = "PanelRamLine"
        Me.PanelRamLine.Size = New System.Drawing.Size(324, 5)
        Me.PanelRamLine.TabIndex = 1
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.FromArgb(CType(CType(1, Byte), Integer), CType(CType(3, Byte), Integer), CType(CType(47, Byte), Integer))
        Me.Panel1.Controls.Add(Me.chk3)
        Me.Panel1.Controls.Add(Me.Panel3)
        Me.Panel1.Controls.Add(Me.chk4)
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Controls.Add(Me.Panel5)
        Me.Panel1.Location = New System.Drawing.Point(51, 190)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(324, 161)
        Me.Panel1.TabIndex = 26
        '
        'chk3
        '
        Me.chk3.BaseColour = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(13, Byte), Integer), CType(CType(58, Byte), Integer))
        Me.chk3.BorderColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.chk3.Checked = False
        Me.chk3.CheckedColour = System.Drawing.Color.FromArgb(CType(CType(231, Byte), Integer), CType(CType(76, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.chk3.Cursor = System.Windows.Forms.Cursors.Hand
        Me.chk3.Font = New System.Drawing.Font("Segoe UI", 8.25!)
        Me.chk3.FontColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.chk3.Location = New System.Drawing.Point(14, 45)
        Me.chk3.Name = "chk3"
        Me.chk3.Size = New System.Drawing.Size(239, 22)
        Me.chk3.TabIndex = 27
        Me.chk3.Text = "Keep the window always in front."
        '
        'chk4
        '
        Me.chk4.BaseColour = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(13, Byte), Integer), CType(CType(58, Byte), Integer))
        Me.chk4.BorderColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.chk4.Checked = True
        Me.chk4.CheckedColour = System.Drawing.Color.FromArgb(CType(CType(231, Byte), Integer), CType(CType(76, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.chk4.Cursor = System.Windows.Forms.Cursors.Hand
        Me.chk4.Font = New System.Drawing.Font("Segoe UI", 8.25!)
        Me.chk4.FontColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.chk4.Location = New System.Drawing.Point(14, 72)
        Me.chk4.Name = "chk4"
        Me.chk4.Size = New System.Drawing.Size(196, 22)
        Me.chk4.TabIndex = 28
        Me.chk4.Text = "Always allow open window."
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 17.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel)
        Me.Label1.ForeColor = System.Drawing.Color.White
        Me.Label1.Location = New System.Drawing.Point(10, 7)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(236, 20)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "MEMORY CLEANER - TAB"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Panel5
        '
        Me.Panel5.BackColor = System.Drawing.Color.DarkGray
        Me.Panel5.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Panel5.Location = New System.Drawing.Point(0, 156)
        Me.Panel5.Name = "Panel5"
        Me.Panel5.Size = New System.Drawing.Size(324, 5)
        Me.Panel5.TabIndex = 1
        '
        'Button2
        '
        Me.Button2.BackColor = System.Drawing.Color.FromArgb(CType(CType(1, Byte), Integer), CType(CType(3, Byte), Integer), CType(CType(47, Byte), Integer))
        Me.Button2.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Button2.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(1, Byte), Integer), CType(CType(3, Byte), Integer), CType(CType(47, Byte), Integer))
        Me.Button2.FlatAppearance.BorderSize = 0
        Me.Button2.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(13, Byte), Integer), CType(CType(58, Byte), Integer))
        Me.Button2.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(1, Byte), Integer), CType(CType(3, Byte), Integer), CType(CType(47, Byte), Integer))
        Me.Button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button2.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel)
        Me.Button2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(29, Byte), Integer), CType(CType(209, Byte), Integer), CType(CType(161, Byte), Integer))
        Me.Button2.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button2.Location = New System.Drawing.Point(51, 364)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(324, 45)
        Me.Button2.TabIndex = 27
        Me.Button2.Text = "SAVE"
        Me.Button2.UseVisualStyleBackColor = False
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel)
        Me.Label4.ForeColor = System.Drawing.Color.FromArgb(CType(CType(105, Byte), Integer), CType(CType(108, Byte), Integer), CType(CType(135, Byte), Integer))
        Me.Label4.Location = New System.Drawing.Point(144, 413)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(138, 15)
        Me.Label4.TabIndex = 28
        Me.Label4.Text = "support@wmcleaner.site"
        '
        'ConfigPanel
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(13, Byte), Integer), CType(CType(58, Byte), Integer))
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.PanelRam)
        Me.DoubleBuffered = True
        Me.Name = "ConfigPanel"
        Me.Size = New System.Drawing.Size(434, 441)
        Me.Panel3.ResumeLayout(False)
        Me.PanelRam.ResumeLayout(False)
        Me.PanelRam.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents chk3 As WinixTHEMECheckBox
    Friend WithEvents chk4 As WinixTHEMECheckBox
    Friend WithEvents Panel3 As Panel
    Friend WithEvents chk5 As WinixTHEMECheckBox
    Friend WithEvents chk1 As WinixTHEMECheckBox
    Friend WithEvents PanelRam As Panel
    Friend WithEvents LabelRam As Label
    Friend WithEvents PanelRamLine As Panel
    Friend WithEvents Panel1 As Panel
    Friend WithEvents Label1 As Label
    Friend WithEvents Panel5 As Panel
    Friend WithEvents Button2 As Button
    Public WithEvents chk2 As WinixTHEMECheckBox
    Friend WithEvents Label4 As Label
End Class
