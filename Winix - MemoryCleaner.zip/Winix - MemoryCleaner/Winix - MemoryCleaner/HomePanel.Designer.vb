﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class HomePanel
    Inherits System.Windows.Forms.UserControl

    'UserControl overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(HomePanel))
        Me.PanelRam = New System.Windows.Forms.Panel()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.lblram = New System.Windows.Forms.Label()
        Me.ramprogressbar = New Winix___MemoryCleaner.WinixTHEMERadialProgressBar()
        Me.LabelRam = New System.Windows.Forms.Label()
        Me.PanelRamLine = New System.Windows.Forms.Panel()
        Me.PanelCpu = New System.Windows.Forms.Panel()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.lblcpu = New System.Windows.Forms.Label()
        Me.pb_cpu = New Winix___MemoryCleaner.WinixTHEMERadialProgressBar()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.PanelCpuLine = New System.Windows.Forms.Panel()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.FlowLayoutPanel1 = New System.Windows.Forms.FlowLayoutPanel()
        Me.btnWindows = New System.Windows.Forms.Panel()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.CheckBox4 = New Winix___MemoryCleaner.WinixTHEMECheckBox()
        Me.CheckBox9 = New Winix___MemoryCleaner.WinixTHEMECheckBox()
        Me.chk4 = New Winix___MemoryCleaner.WinixTHEMECheckBox()
        Me.chk2 = New Winix___MemoryCleaner.WinixTHEMECheckBox()
        Me.chk3 = New Winix___MemoryCleaner.WinixTHEMECheckBox()
        Me.chk12 = New Winix___MemoryCleaner.WinixTHEMECheckBox()
        Me.chk13 = New Winix___MemoryCleaner.WinixTHEMECheckBox()
        Me.chk14 = New Winix___MemoryCleaner.WinixTHEMECheckBox()
        Me.chk16 = New Winix___MemoryCleaner.WinixTHEMECheckBox()
        Me.chk17 = New Winix___MemoryCleaner.WinixTHEMECheckBox()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.CheckBox2 = New Winix___MemoryCleaner.WinixTHEMECheckBox()
        Me.CheckBox8 = New Winix___MemoryCleaner.WinixTHEMECheckBox()
        Me.CheckBox3 = New Winix___MemoryCleaner.WinixTHEMECheckBox()
        Me.CheckBox1 = New Winix___MemoryCleaner.WinixTHEMECheckBox()
        Me.chk5 = New Winix___MemoryCleaner.WinixTHEMECheckBox()
        Me.chk7 = New Winix___MemoryCleaner.WinixTHEMECheckBox()
        Me.chk9 = New Winix___MemoryCleaner.WinixTHEMECheckBox()
        Me.chk8 = New Winix___MemoryCleaner.WinixTHEMECheckBox()
        Me.chk6 = New Winix___MemoryCleaner.WinixTHEMECheckBox()
        Me.chk11 = New Winix___MemoryCleaner.WinixTHEMECheckBox()
        Me.chk18 = New Winix___MemoryCleaner.WinixTHEMECheckBox()
        Me.Panel5 = New System.Windows.Forms.Panel()
        Me.PictureBox3 = New System.Windows.Forms.PictureBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.CheckBox7 = New Winix___MemoryCleaner.WinixTHEMECheckBox()
        Me.network2 = New Winix___MemoryCleaner.WinixTHEMECheckBox()
        Me.network1 = New Winix___MemoryCleaner.WinixTHEMECheckBox()
        Me.chk10 = New Winix___MemoryCleaner.WinixTHEMECheckBox()
        Me.network3 = New Winix___MemoryCleaner.WinixTHEMECheckBox()
        Me.chk15 = New Winix___MemoryCleaner.WinixTHEMECheckBox()
        Me.Panel6 = New System.Windows.Forms.Panel()
        Me.PictureBox4 = New System.Windows.Forms.PictureBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.CheckBox6 = New Winix___MemoryCleaner.WinixTHEMECheckBox()
        Me.CheckBox5 = New Winix___MemoryCleaner.WinixTHEMECheckBox()
        Me.Panel7 = New System.Windows.Forms.Panel()
        Me.PictureBox5 = New System.Windows.Forms.PictureBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.limparlixeira = New Winix___MemoryCleaner.WinixTHEMECheckBox()
        Me.CheckBox10 = New Winix___MemoryCleaner.WinixTHEMECheckBox()
        Me.CheckBox11 = New Winix___MemoryCleaner.WinixTHEMECheckBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.TimerCPU = New System.Windows.Forms.Timer(Me.components)
        Me.TimerRAM = New System.Windows.Forms.Timer(Me.components)
        Me.TimerReleaseMemory = New System.Windows.Forms.Timer(Me.components)
        Me.lwProcs = New System.Windows.Forms.ListView()
        Me.coluna5 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader1 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader2 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader3 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader4 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.pc_CPU = New System.Diagnostics.PerformanceCounter()
        Me.imgIcons = New System.Windows.Forms.ImageList(Me.components)
        Me.BackgroundWorker1 = New System.ComponentModel.BackgroundWorker()
        Me.TimerSpeedWindows = New System.Windows.Forms.Timer(Me.components)
        Me.ListView1 = New System.Windows.Forms.ListView()
        Me.ColumnHeader5 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader6 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.Timer2 = New System.Windows.Forms.Timer(Me.components)
        Me.lblMemoriaDisponivel = New System.Windows.Forms.Label()
        Me.panelads = New System.Windows.Forms.PictureBox()
        Me.ProgressBar1 = New Winix___MemoryCleaner.WinixTHEMEProgressBar()
        Me.PanelRam.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.PanelCpu.SuspendLayout()
        Me.Panel3.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.FlowLayoutPanel1.SuspendLayout()
        Me.btnWindows.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel4.SuspendLayout()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel5.SuspendLayout()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel6.SuspendLayout()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel7.SuspendLayout()
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pc_CPU, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.panelads, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'PanelRam
        '
        Me.PanelRam.BackColor = System.Drawing.Color.FromArgb(CType(CType(1, Byte), Integer), CType(CType(3, Byte), Integer), CType(CType(47, Byte), Integer))
        Me.PanelRam.Controls.Add(Me.Panel2)
        Me.PanelRam.Controls.Add(Me.ramprogressbar)
        Me.PanelRam.Controls.Add(Me.LabelRam)
        Me.PanelRam.Controls.Add(Me.PanelRamLine)
        Me.PanelRam.Location = New System.Drawing.Point(12, 13)
        Me.PanelRam.Name = "PanelRam"
        Me.PanelRam.Size = New System.Drawing.Size(160, 165)
        Me.PanelRam.TabIndex = 0
        '
        'Panel2
        '
        Me.Panel2.Controls.Add(Me.lblram)
        Me.Panel2.Location = New System.Drawing.Point(51, 68)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(58, 50)
        Me.Panel2.TabIndex = 25
        '
        'lblram
        '
        Me.lblram.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel)
        Me.lblram.ForeColor = System.Drawing.Color.FromArgb(CType(CType(105, Byte), Integer), CType(CType(108, Byte), Integer), CType(CType(135, Byte), Integer))
        Me.lblram.Location = New System.Drawing.Point(0, 11)
        Me.lblram.Name = "lblram"
        Me.lblram.Size = New System.Drawing.Size(58, 24)
        Me.lblram.TabIndex = 26
        Me.lblram.Text = "0%"
        Me.lblram.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'ramprogressbar
        '
        Me.ramprogressbar.BackColor = System.Drawing.Color.Transparent
        Me.ramprogressbar.BaseColour = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(13, Byte), Integer), CType(CType(58, Byte), Integer))
        Me.ramprogressbar.BorderColour = System.Drawing.Color.Transparent
        Me.ramprogressbar.Location = New System.Drawing.Point(25, 37)
        Me.ramprogressbar.Maximum = 100
        Me.ramprogressbar.Name = "ramprogressbar"
        Me.ramprogressbar.ProgressColour = System.Drawing.Color.FromArgb(CType(CType(105, Byte), Integer), CType(CType(108, Byte), Integer), CType(CType(135, Byte), Integer))
        Me.ramprogressbar.RotationAngle = 280
        Me.ramprogressbar.Size = New System.Drawing.Size(110, 110)
        Me.ramprogressbar.StartingAngle = 130
        Me.ramprogressbar.TabIndex = 3
        Me.ramprogressbar.Value = 0
        '
        'LabelRam
        '
        Me.LabelRam.AutoSize = True
        Me.LabelRam.Font = New System.Drawing.Font("Microsoft Sans Serif", 17.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel)
        Me.LabelRam.ForeColor = System.Drawing.Color.White
        Me.LabelRam.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.LabelRam.Location = New System.Drawing.Point(10, 7)
        Me.LabelRam.Name = "LabelRam"
        Me.LabelRam.Size = New System.Drawing.Size(49, 20)
        Me.LabelRam.TabIndex = 2
        Me.LabelRam.Text = "RAM"
        Me.LabelRam.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'PanelRamLine
        '
        Me.PanelRamLine.BackColor = System.Drawing.Color.DarkGray
        Me.PanelRamLine.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.PanelRamLine.Location = New System.Drawing.Point(0, 160)
        Me.PanelRamLine.Name = "PanelRamLine"
        Me.PanelRamLine.Size = New System.Drawing.Size(160, 5)
        Me.PanelRamLine.TabIndex = 1
        '
        'PanelCpu
        '
        Me.PanelCpu.BackColor = System.Drawing.Color.FromArgb(CType(CType(1, Byte), Integer), CType(CType(3, Byte), Integer), CType(CType(47, Byte), Integer))
        Me.PanelCpu.Controls.Add(Me.Panel3)
        Me.PanelCpu.Controls.Add(Me.pb_cpu)
        Me.PanelCpu.Controls.Add(Me.Label1)
        Me.PanelCpu.Controls.Add(Me.PanelCpuLine)
        Me.PanelCpu.Location = New System.Drawing.Point(12, 186)
        Me.PanelCpu.Name = "PanelCpu"
        Me.PanelCpu.Size = New System.Drawing.Size(160, 165)
        Me.PanelCpu.TabIndex = 2
        '
        'Panel3
        '
        Me.Panel3.Controls.Add(Me.lblcpu)
        Me.Panel3.Location = New System.Drawing.Point(51, 69)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(58, 50)
        Me.Panel3.TabIndex = 26
        '
        'lblcpu
        '
        Me.lblcpu.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel)
        Me.lblcpu.ForeColor = System.Drawing.Color.FromArgb(CType(CType(105, Byte), Integer), CType(CType(108, Byte), Integer), CType(CType(135, Byte), Integer))
        Me.lblcpu.Location = New System.Drawing.Point(0, 12)
        Me.lblcpu.Name = "lblcpu"
        Me.lblcpu.Size = New System.Drawing.Size(58, 24)
        Me.lblcpu.TabIndex = 27
        Me.lblcpu.Text = "0%"
        Me.lblcpu.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'pb_cpu
        '
        Me.pb_cpu.BackColor = System.Drawing.Color.Transparent
        Me.pb_cpu.BaseColour = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(13, Byte), Integer), CType(CType(58, Byte), Integer))
        Me.pb_cpu.BorderColour = System.Drawing.Color.Transparent
        Me.pb_cpu.Location = New System.Drawing.Point(25, 38)
        Me.pb_cpu.Maximum = 100
        Me.pb_cpu.Name = "pb_cpu"
        Me.pb_cpu.ProgressColour = System.Drawing.Color.FromArgb(CType(CType(105, Byte), Integer), CType(CType(108, Byte), Integer), CType(CType(135, Byte), Integer))
        Me.pb_cpu.RotationAngle = 280
        Me.pb_cpu.Size = New System.Drawing.Size(110, 110)
        Me.pb_cpu.StartingAngle = 130
        Me.pb_cpu.TabIndex = 4
        Me.pb_cpu.Text = "WinixTHEMERadialProgressBar2"
        Me.pb_cpu.Value = 0
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 17.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel)
        Me.Label1.ForeColor = System.Drawing.Color.White
        Me.Label1.Location = New System.Drawing.Point(10, 6)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(47, 20)
        Me.Label1.TabIndex = 3
        Me.Label1.Text = "CPU"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'PanelCpuLine
        '
        Me.PanelCpuLine.BackColor = System.Drawing.Color.DarkGray
        Me.PanelCpuLine.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.PanelCpuLine.Location = New System.Drawing.Point(0, 160)
        Me.PanelCpuLine.Name = "PanelCpuLine"
        Me.PanelCpuLine.Size = New System.Drawing.Size(160, 5)
        Me.PanelCpuLine.TabIndex = 1
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.FromArgb(CType(CType(1, Byte), Integer), CType(CType(3, Byte), Integer), CType(CType(47, Byte), Integer))
        Me.Panel1.Controls.Add(Me.FlowLayoutPanel1)
        Me.Panel1.Controls.Add(Me.Label2)
        Me.Panel1.Location = New System.Drawing.Point(183, 13)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(234, 338)
        Me.Panel1.TabIndex = 3
        '
        'FlowLayoutPanel1
        '
        Me.FlowLayoutPanel1.AutoScroll = True
        Me.FlowLayoutPanel1.Controls.Add(Me.btnWindows)
        Me.FlowLayoutPanel1.Controls.Add(Me.CheckBox4)
        Me.FlowLayoutPanel1.Controls.Add(Me.CheckBox9)
        Me.FlowLayoutPanel1.Controls.Add(Me.chk4)
        Me.FlowLayoutPanel1.Controls.Add(Me.chk2)
        Me.FlowLayoutPanel1.Controls.Add(Me.chk3)
        Me.FlowLayoutPanel1.Controls.Add(Me.chk12)
        Me.FlowLayoutPanel1.Controls.Add(Me.chk13)
        Me.FlowLayoutPanel1.Controls.Add(Me.chk14)
        Me.FlowLayoutPanel1.Controls.Add(Me.chk16)
        Me.FlowLayoutPanel1.Controls.Add(Me.chk17)
        Me.FlowLayoutPanel1.Controls.Add(Me.Panel4)
        Me.FlowLayoutPanel1.Controls.Add(Me.CheckBox2)
        Me.FlowLayoutPanel1.Controls.Add(Me.CheckBox8)
        Me.FlowLayoutPanel1.Controls.Add(Me.CheckBox3)
        Me.FlowLayoutPanel1.Controls.Add(Me.CheckBox1)
        Me.FlowLayoutPanel1.Controls.Add(Me.chk5)
        Me.FlowLayoutPanel1.Controls.Add(Me.chk7)
        Me.FlowLayoutPanel1.Controls.Add(Me.chk9)
        Me.FlowLayoutPanel1.Controls.Add(Me.chk8)
        Me.FlowLayoutPanel1.Controls.Add(Me.chk6)
        Me.FlowLayoutPanel1.Controls.Add(Me.chk11)
        Me.FlowLayoutPanel1.Controls.Add(Me.chk18)
        Me.FlowLayoutPanel1.Controls.Add(Me.Panel5)
        Me.FlowLayoutPanel1.Controls.Add(Me.CheckBox7)
        Me.FlowLayoutPanel1.Controls.Add(Me.network2)
        Me.FlowLayoutPanel1.Controls.Add(Me.network1)
        Me.FlowLayoutPanel1.Controls.Add(Me.chk10)
        Me.FlowLayoutPanel1.Controls.Add(Me.network3)
        Me.FlowLayoutPanel1.Controls.Add(Me.chk15)
        Me.FlowLayoutPanel1.Controls.Add(Me.Panel6)
        Me.FlowLayoutPanel1.Controls.Add(Me.CheckBox6)
        Me.FlowLayoutPanel1.Controls.Add(Me.CheckBox5)
        Me.FlowLayoutPanel1.Controls.Add(Me.Panel7)
        Me.FlowLayoutPanel1.Controls.Add(Me.limparlixeira)
        Me.FlowLayoutPanel1.Controls.Add(Me.CheckBox10)
        Me.FlowLayoutPanel1.Controls.Add(Me.CheckBox11)
        Me.FlowLayoutPanel1.FlowDirection = System.Windows.Forms.FlowDirection.TopDown
        Me.FlowLayoutPanel1.Location = New System.Drawing.Point(5, 37)
        Me.FlowLayoutPanel1.Name = "FlowLayoutPanel1"
        Me.FlowLayoutPanel1.Size = New System.Drawing.Size(229, 298)
        Me.FlowLayoutPanel1.TabIndex = 38
        Me.FlowLayoutPanel1.WrapContents = False
        '
        'btnWindows
        '
        Me.btnWindows.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(13, Byte), Integer), CType(CType(58, Byte), Integer))
        Me.btnWindows.Controls.Add(Me.PictureBox1)
        Me.btnWindows.Controls.Add(Me.Label3)
        Me.btnWindows.Cursor = System.Windows.Forms.Cursors.Arrow
        Me.btnWindows.Location = New System.Drawing.Point(3, 3)
        Me.btnWindows.Name = "btnWindows"
        Me.btnWindows.Size = New System.Drawing.Size(200, 32)
        Me.btnWindows.TabIndex = 41
        '
        'PictureBox1
        '
        Me.PictureBox1.Cursor = System.Windows.Forms.Cursors.Arrow
        Me.PictureBox1.Image = Global.Winix___MemoryCleaner.My.Resources.Resources.Windows_Client_48px
        Me.PictureBox1.Location = New System.Drawing.Point(10, 3)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(25, 25)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 1
        Me.PictureBox1.TabStop = False
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Cursor = System.Windows.Forms.Cursors.Arrow
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
        Me.Label3.ForeColor = System.Drawing.Color.White
        Me.Label3.Location = New System.Drawing.Point(40, 6)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(77, 17)
        Me.Label3.TabIndex = 0
        Me.Label3.Text = "WINDOWS"
        '
        'CheckBox4
        '
        Me.CheckBox4.BaseColour = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(13, Byte), Integer), CType(CType(58, Byte), Integer))
        Me.CheckBox4.BorderColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.CheckBox4.Checked = True
        Me.CheckBox4.CheckedColour = System.Drawing.Color.FromArgb(CType(CType(231, Byte), Integer), CType(CType(76, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.CheckBox4.Cursor = System.Windows.Forms.Cursors.Hand
        Me.CheckBox4.FontColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.CheckBox4.Location = New System.Drawing.Point(3, 41)
        Me.CheckBox4.Name = "CheckBox4"
        Me.CheckBox4.Size = New System.Drawing.Size(184, 22)
        Me.CheckBox4.TabIndex = 24
        Me.CheckBox4.Text = "Speed Up Windows"
        '
        'CheckBox9
        '
        Me.CheckBox9.BaseColour = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(13, Byte), Integer), CType(CType(58, Byte), Integer))
        Me.CheckBox9.BorderColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.CheckBox9.Checked = False
        Me.CheckBox9.CheckedColour = System.Drawing.Color.FromArgb(CType(CType(231, Byte), Integer), CType(CType(76, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.CheckBox9.Cursor = System.Windows.Forms.Cursors.Hand
        Me.CheckBox9.FontColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.CheckBox9.Location = New System.Drawing.Point(3, 69)
        Me.CheckBox9.Name = "CheckBox9"
        Me.CheckBox9.Size = New System.Drawing.Size(184, 22)
        Me.CheckBox9.TabIndex = 25
        Me.CheckBox9.Text = "Speed Up : CMD"
        '
        'chk4
        '
        Me.chk4.BaseColour = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(13, Byte), Integer), CType(CType(58, Byte), Integer))
        Me.chk4.BorderColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.chk4.Checked = False
        Me.chk4.CheckedColour = System.Drawing.Color.FromArgb(CType(CType(231, Byte), Integer), CType(CType(76, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.chk4.Cursor = System.Windows.Forms.Cursors.Hand
        Me.chk4.Font = New System.Drawing.Font("Century Gothic", 9.0!)
        Me.chk4.FontColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.chk4.Location = New System.Drawing.Point(3, 97)
        Me.chk4.Name = "chk4"
        Me.chk4.Size = New System.Drawing.Size(164, 22)
        Me.chk4.TabIndex = 26
        Me.chk4.Text = "Windows Update"
        '
        'chk2
        '
        Me.chk2.BaseColour = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(13, Byte), Integer), CType(CType(58, Byte), Integer))
        Me.chk2.BorderColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.chk2.Checked = False
        Me.chk2.CheckedColour = System.Drawing.Color.FromArgb(CType(CType(231, Byte), Integer), CType(CType(76, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.chk2.Cursor = System.Windows.Forms.Cursors.Hand
        Me.chk2.Font = New System.Drawing.Font("Century Gothic", 9.0!)
        Me.chk2.FontColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.chk2.Location = New System.Drawing.Point(3, 125)
        Me.chk2.Name = "chk2"
        Me.chk2.Size = New System.Drawing.Size(184, 22)
        Me.chk2.TabIndex = 24
        Me.chk2.Text = "Windows Defender"
        '
        'chk3
        '
        Me.chk3.BaseColour = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(13, Byte), Integer), CType(CType(58, Byte), Integer))
        Me.chk3.BorderColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.chk3.Checked = False
        Me.chk3.CheckedColour = System.Drawing.Color.FromArgb(CType(CType(231, Byte), Integer), CType(CType(76, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.chk3.Cursor = System.Windows.Forms.Cursors.Hand
        Me.chk3.Font = New System.Drawing.Font("Century Gothic", 9.0!)
        Me.chk3.FontColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.chk3.Location = New System.Drawing.Point(3, 153)
        Me.chk3.Name = "chk3"
        Me.chk3.Size = New System.Drawing.Size(184, 22)
        Me.chk3.TabIndex = 25
        Me.chk3.Text = "Windows Search"
        '
        'chk12
        '
        Me.chk12.BaseColour = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(13, Byte), Integer), CType(CType(58, Byte), Integer))
        Me.chk12.BorderColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.chk12.Checked = False
        Me.chk12.CheckedColour = System.Drawing.Color.FromArgb(CType(CType(231, Byte), Integer), CType(CType(76, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.chk12.Cursor = System.Windows.Forms.Cursors.Hand
        Me.chk12.Font = New System.Drawing.Font("Century Gothic", 9.0!)
        Me.chk12.FontColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.chk12.Location = New System.Drawing.Point(3, 181)
        Me.chk12.Name = "chk12"
        Me.chk12.Size = New System.Drawing.Size(200, 22)
        Me.chk12.TabIndex = 34
        Me.chk12.Text = "Windows Error Reporting Services"
        Me.chk12.Visible = False
        '
        'chk13
        '
        Me.chk13.BaseColour = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(13, Byte), Integer), CType(CType(58, Byte), Integer))
        Me.chk13.BorderColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.chk13.Checked = False
        Me.chk13.CheckedColour = System.Drawing.Color.FromArgb(CType(CType(231, Byte), Integer), CType(CType(76, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.chk13.Cursor = System.Windows.Forms.Cursors.Hand
        Me.chk13.Font = New System.Drawing.Font("Century Gothic", 9.0!)
        Me.chk13.FontColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.chk13.Location = New System.Drawing.Point(3, 209)
        Me.chk13.Name = "chk13"
        Me.chk13.Size = New System.Drawing.Size(184, 22)
        Me.chk13.TabIndex = 35
        Me.chk13.Text = "Windows Firewall"
        '
        'chk14
        '
        Me.chk14.BaseColour = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(13, Byte), Integer), CType(CType(58, Byte), Integer))
        Me.chk14.BorderColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.chk14.Checked = False
        Me.chk14.CheckedColour = System.Drawing.Color.FromArgb(CType(CType(231, Byte), Integer), CType(CType(76, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.chk14.Cursor = System.Windows.Forms.Cursors.Hand
        Me.chk14.Font = New System.Drawing.Font("Century Gothic", 9.0!)
        Me.chk14.FontColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.chk14.Location = New System.Drawing.Point(3, 237)
        Me.chk14.Name = "chk14"
        Me.chk14.Size = New System.Drawing.Size(184, 22)
        Me.chk14.TabIndex = 36
        Me.chk14.Text = "Windows Image Acquisition"
        '
        'chk16
        '
        Me.chk16.BaseColour = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(13, Byte), Integer), CType(CType(58, Byte), Integer))
        Me.chk16.BorderColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.chk16.Checked = False
        Me.chk16.CheckedColour = System.Drawing.Color.FromArgb(CType(CType(231, Byte), Integer), CType(CType(76, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.chk16.Cursor = System.Windows.Forms.Cursors.Hand
        Me.chk16.Font = New System.Drawing.Font("Century Gothic", 9.0!)
        Me.chk16.FontColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.chk16.Location = New System.Drawing.Point(3, 265)
        Me.chk16.Name = "chk16"
        Me.chk16.Size = New System.Drawing.Size(192, 22)
        Me.chk16.TabIndex = 38
        Me.chk16.Text = "Windows Biometrics Service"
        '
        'chk17
        '
        Me.chk17.BaseColour = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(13, Byte), Integer), CType(CType(58, Byte), Integer))
        Me.chk17.BorderColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.chk17.Checked = False
        Me.chk17.CheckedColour = System.Drawing.Color.FromArgb(CType(CType(231, Byte), Integer), CType(CType(76, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.chk17.Cursor = System.Windows.Forms.Cursors.Hand
        Me.chk17.Font = New System.Drawing.Font("Century Gothic", 9.0!)
        Me.chk17.FontColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.chk17.Location = New System.Drawing.Point(3, 293)
        Me.chk17.Name = "chk17"
        Me.chk17.Size = New System.Drawing.Size(184, 22)
        Me.chk17.TabIndex = 39
        Me.chk17.Text = "Windows M.C Scheduler"
        '
        'Panel4
        '
        Me.Panel4.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(13, Byte), Integer), CType(CType(58, Byte), Integer))
        Me.Panel4.Controls.Add(Me.PictureBox2)
        Me.Panel4.Controls.Add(Me.Label4)
        Me.Panel4.Cursor = System.Windows.Forms.Cursors.Arrow
        Me.Panel4.Location = New System.Drawing.Point(3, 321)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(200, 32)
        Me.Panel4.TabIndex = 42
        '
        'PictureBox2
        '
        Me.PictureBox2.Cursor = System.Windows.Forms.Cursors.Arrow
        Me.PictureBox2.Image = Global.Winix___MemoryCleaner.My.Resources.Resources.maintenence_icon
        Me.PictureBox2.Location = New System.Drawing.Point(10, 3)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(25, 25)
        Me.PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox2.TabIndex = 1
        Me.PictureBox2.TabStop = False
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Cursor = System.Windows.Forms.Cursors.Arrow
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
        Me.Label4.ForeColor = System.Drawing.Color.White
        Me.Label4.Location = New System.Drawing.Point(40, 6)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(106, 17)
        Me.Label4.TabIndex = 0
        Me.Label4.Text = "MAINTENANCE"
        '
        'CheckBox2
        '
        Me.CheckBox2.BaseColour = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(13, Byte), Integer), CType(CType(58, Byte), Integer))
        Me.CheckBox2.BorderColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.CheckBox2.Checked = False
        Me.CheckBox2.CheckedColour = System.Drawing.Color.FromArgb(CType(CType(231, Byte), Integer), CType(CType(76, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.CheckBox2.Cursor = System.Windows.Forms.Cursors.Hand
        Me.CheckBox2.FontColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.CheckBox2.Location = New System.Drawing.Point(3, 359)
        Me.CheckBox2.Name = "CheckBox2"
        Me.CheckBox2.Size = New System.Drawing.Size(184, 22)
        Me.CheckBox2.TabIndex = 27
        Me.CheckBox2.Text = "Disable Aero Snap"
        '
        'CheckBox8
        '
        Me.CheckBox8.BaseColour = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(13, Byte), Integer), CType(CType(58, Byte), Integer))
        Me.CheckBox8.BorderColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.CheckBox8.Checked = False
        Me.CheckBox8.CheckedColour = System.Drawing.Color.FromArgb(CType(CType(231, Byte), Integer), CType(CType(76, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.CheckBox8.Cursor = System.Windows.Forms.Cursors.Hand
        Me.CheckBox8.FontColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.CheckBox8.Location = New System.Drawing.Point(3, 387)
        Me.CheckBox8.Name = "CheckBox8"
        Me.CheckBox8.Size = New System.Drawing.Size(184, 22)
        Me.CheckBox8.TabIndex = 28
        Me.CheckBox8.Text = "Disable Aero"
        '
        'CheckBox3
        '
        Me.CheckBox3.BaseColour = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(13, Byte), Integer), CType(CType(58, Byte), Integer))
        Me.CheckBox3.BorderColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.CheckBox3.Checked = True
        Me.CheckBox3.CheckedColour = System.Drawing.Color.FromArgb(CType(CType(231, Byte), Integer), CType(CType(76, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.CheckBox3.Cursor = System.Windows.Forms.Cursors.Hand
        Me.CheckBox3.FontColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.CheckBox3.Location = New System.Drawing.Point(3, 415)
        Me.CheckBox3.Name = "CheckBox3"
        Me.CheckBox3.Size = New System.Drawing.Size(184, 22)
        Me.CheckBox3.TabIndex = 29
        Me.CheckBox3.Text = "Decrease Animation Delay"
        '
        'CheckBox1
        '
        Me.CheckBox1.BaseColour = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(13, Byte), Integer), CType(CType(58, Byte), Integer))
        Me.CheckBox1.BorderColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.CheckBox1.Checked = True
        Me.CheckBox1.CheckedColour = System.Drawing.Color.FromArgb(CType(CType(231, Byte), Integer), CType(CType(76, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.CheckBox1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.CheckBox1.FontColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.CheckBox1.Location = New System.Drawing.Point(3, 443)
        Me.CheckBox1.Name = "CheckBox1"
        Me.CheckBox1.Size = New System.Drawing.Size(184, 22)
        Me.CheckBox1.TabIndex = 32
        Me.CheckBox1.Text = "Start Programs Quickly"
        '
        'chk5
        '
        Me.chk5.BaseColour = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(13, Byte), Integer), CType(CType(58, Byte), Integer))
        Me.chk5.BorderColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.chk5.Checked = False
        Me.chk5.CheckedColour = System.Drawing.Color.FromArgb(CType(CType(231, Byte), Integer), CType(CType(76, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.chk5.Cursor = System.Windows.Forms.Cursors.Hand
        Me.chk5.Font = New System.Drawing.Font("Century Gothic", 9.0!)
        Me.chk5.FontColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.chk5.Location = New System.Drawing.Point(3, 471)
        Me.chk5.Name = "chk5"
        Me.chk5.Size = New System.Drawing.Size(184, 22)
        Me.chk5.TabIndex = 27
        Me.chk5.Text = "Print Spooler"
        '
        'chk7
        '
        Me.chk7.BaseColour = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(13, Byte), Integer), CType(CType(58, Byte), Integer))
        Me.chk7.BorderColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.chk7.Checked = False
        Me.chk7.CheckedColour = System.Drawing.Color.FromArgb(CType(CType(231, Byte), Integer), CType(CType(76, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.chk7.Cursor = System.Windows.Forms.Cursors.Hand
        Me.chk7.Font = New System.Drawing.Font("Century Gothic", 9.0!)
        Me.chk7.FontColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.chk7.Location = New System.Drawing.Point(3, 499)
        Me.chk7.Name = "chk7"
        Me.chk7.Size = New System.Drawing.Size(164, 22)
        Me.chk7.TabIndex = 29
        Me.chk7.Text = "Security Center"
        '
        'chk9
        '
        Me.chk9.BaseColour = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(13, Byte), Integer), CType(CType(58, Byte), Integer))
        Me.chk9.BorderColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.chk9.Checked = False
        Me.chk9.CheckedColour = System.Drawing.Color.FromArgb(CType(CType(231, Byte), Integer), CType(CType(76, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.chk9.Cursor = System.Windows.Forms.Cursors.Hand
        Me.chk9.Font = New System.Drawing.Font("Century Gothic", 9.0!)
        Me.chk9.FontColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.chk9.Location = New System.Drawing.Point(3, 527)
        Me.chk9.Name = "chk9"
        Me.chk9.Size = New System.Drawing.Size(184, 22)
        Me.chk9.TabIndex = 31
        Me.chk9.Text = "Adaptive Brightness"
        '
        'chk8
        '
        Me.chk8.BaseColour = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(13, Byte), Integer), CType(CType(58, Byte), Integer))
        Me.chk8.BorderColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.chk8.Checked = False
        Me.chk8.CheckedColour = System.Drawing.Color.FromArgb(CType(CType(231, Byte), Integer), CType(CType(76, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.chk8.Cursor = System.Windows.Forms.Cursors.Hand
        Me.chk8.Font = New System.Drawing.Font("Century Gothic", 9.0!)
        Me.chk8.FontColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.chk8.Location = New System.Drawing.Point(3, 555)
        Me.chk8.Name = "chk8"
        Me.chk8.Size = New System.Drawing.Size(164, 22)
        Me.chk8.TabIndex = 30
        Me.chk8.Text = "Secondary Logon"
        '
        'chk6
        '
        Me.chk6.BaseColour = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(13, Byte), Integer), CType(CType(58, Byte), Integer))
        Me.chk6.BorderColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.chk6.Checked = False
        Me.chk6.CheckedColour = System.Drawing.Color.FromArgb(CType(CType(231, Byte), Integer), CType(CType(76, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.chk6.Cursor = System.Windows.Forms.Cursors.Hand
        Me.chk6.Font = New System.Drawing.Font("Century Gothic", 9.0!)
        Me.chk6.FontColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.chk6.Location = New System.Drawing.Point(3, 583)
        Me.chk6.Name = "chk6"
        Me.chk6.Size = New System.Drawing.Size(164, 22)
        Me.chk6.TabIndex = 28
        Me.chk6.Text = "Smart Card"
        '
        'chk11
        '
        Me.chk11.BaseColour = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(13, Byte), Integer), CType(CType(58, Byte), Integer))
        Me.chk11.BorderColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.chk11.Checked = False
        Me.chk11.CheckedColour = System.Drawing.Color.FromArgb(CType(CType(231, Byte), Integer), CType(CType(76, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.chk11.Cursor = System.Windows.Forms.Cursors.Hand
        Me.chk11.Font = New System.Drawing.Font("Century Gothic", 9.0!)
        Me.chk11.FontColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.chk11.Location = New System.Drawing.Point(3, 611)
        Me.chk11.Name = "chk11"
        Me.chk11.Size = New System.Drawing.Size(184, 22)
        Me.chk11.TabIndex = 33
        Me.chk11.Text = "Encryption Services"
        '
        'chk18
        '
        Me.chk18.BaseColour = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(13, Byte), Integer), CType(CType(58, Byte), Integer))
        Me.chk18.BorderColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.chk18.Checked = False
        Me.chk18.CheckedColour = System.Drawing.Color.FromArgb(CType(CType(231, Byte), Integer), CType(CType(76, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.chk18.Cursor = System.Windows.Forms.Cursors.Hand
        Me.chk18.Font = New System.Drawing.Font("Century Gothic", 9.0!)
        Me.chk18.FontColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.chk18.Location = New System.Drawing.Point(3, 639)
        Me.chk18.Name = "chk18"
        Me.chk18.Size = New System.Drawing.Size(184, 22)
        Me.chk18.TabIndex = 40
        Me.chk18.Text = "Superfetch"
        '
        'Panel5
        '
        Me.Panel5.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(13, Byte), Integer), CType(CType(58, Byte), Integer))
        Me.Panel5.Controls.Add(Me.PictureBox3)
        Me.Panel5.Controls.Add(Me.Label5)
        Me.Panel5.Cursor = System.Windows.Forms.Cursors.Arrow
        Me.Panel5.Location = New System.Drawing.Point(3, 667)
        Me.Panel5.Name = "Panel5"
        Me.Panel5.Size = New System.Drawing.Size(200, 32)
        Me.Panel5.TabIndex = 43
        '
        'PictureBox3
        '
        Me.PictureBox3.Cursor = System.Windows.Forms.Cursors.Arrow
        Me.PictureBox3.Image = Global.Winix___MemoryCleaner.My.Resources.Resources.rede_icon
        Me.PictureBox3.Location = New System.Drawing.Point(10, 3)
        Me.PictureBox3.Name = "PictureBox3"
        Me.PictureBox3.Size = New System.Drawing.Size(25, 25)
        Me.PictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox3.TabIndex = 1
        Me.PictureBox3.TabStop = False
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Cursor = System.Windows.Forms.Cursors.Arrow
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
        Me.Label5.ForeColor = System.Drawing.Color.White
        Me.Label5.Location = New System.Drawing.Point(40, 6)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(79, 17)
        Me.Label5.TabIndex = 0
        Me.Label5.Text = "NETWORK"
        '
        'CheckBox7
        '
        Me.CheckBox7.BaseColour = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(13, Byte), Integer), CType(CType(58, Byte), Integer))
        Me.CheckBox7.BorderColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.CheckBox7.Checked = False
        Me.CheckBox7.CheckedColour = System.Drawing.Color.FromArgb(CType(CType(231, Byte), Integer), CType(CType(76, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.CheckBox7.Cursor = System.Windows.Forms.Cursors.Hand
        Me.CheckBox7.FontColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.CheckBox7.Location = New System.Drawing.Point(3, 705)
        Me.CheckBox7.Name = "CheckBox7"
        Me.CheckBox7.Size = New System.Drawing.Size(164, 22)
        Me.CheckBox7.TabIndex = 31
        Me.CheckBox7.Text = "Transfer Rate"
        '
        'network2
        '
        Me.network2.BaseColour = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(13, Byte), Integer), CType(CType(58, Byte), Integer))
        Me.network2.BorderColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.network2.Checked = False
        Me.network2.CheckedColour = System.Drawing.Color.FromArgb(CType(CType(231, Byte), Integer), CType(CType(76, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.network2.Cursor = System.Windows.Forms.Cursors.Hand
        Me.network2.Font = New System.Drawing.Font("Century Gothic", 9.0!)
        Me.network2.FontColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.network2.Location = New System.Drawing.Point(3, 733)
        Me.network2.Name = "network2"
        Me.network2.Size = New System.Drawing.Size(200, 22)
        Me.network2.TabIndex = 47
        Me.network2.Text = "Reset DNS"
        '
        'network1
        '
        Me.network1.BaseColour = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(13, Byte), Integer), CType(CType(58, Byte), Integer))
        Me.network1.BorderColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.network1.Checked = False
        Me.network1.CheckedColour = System.Drawing.Color.FromArgb(CType(CType(231, Byte), Integer), CType(CType(76, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.network1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.network1.Font = New System.Drawing.Font("Century Gothic", 9.0!)
        Me.network1.FontColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.network1.Location = New System.Drawing.Point(3, 761)
        Me.network1.Name = "network1"
        Me.network1.Size = New System.Drawing.Size(200, 22)
        Me.network1.TabIndex = 46
        Me.network1.Text = "Reset TCP/IP"
        '
        'chk10
        '
        Me.chk10.BaseColour = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(13, Byte), Integer), CType(CType(58, Byte), Integer))
        Me.chk10.BorderColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.chk10.Checked = False
        Me.chk10.CheckedColour = System.Drawing.Color.FromArgb(CType(CType(231, Byte), Integer), CType(CType(76, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.chk10.Cursor = System.Windows.Forms.Cursors.Hand
        Me.chk10.Font = New System.Drawing.Font("Century Gothic", 9.0!)
        Me.chk10.FontColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.chk10.Location = New System.Drawing.Point(3, 789)
        Me.chk10.Name = "chk10"
        Me.chk10.Size = New System.Drawing.Size(200, 22)
        Me.chk10.TabIndex = 32
        Me.chk10.Text = "Routing and Remote Access"
        '
        'network3
        '
        Me.network3.BaseColour = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(13, Byte), Integer), CType(CType(58, Byte), Integer))
        Me.network3.BorderColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.network3.Checked = False
        Me.network3.CheckedColour = System.Drawing.Color.FromArgb(CType(CType(231, Byte), Integer), CType(CType(76, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.network3.Cursor = System.Windows.Forms.Cursors.Hand
        Me.network3.Font = New System.Drawing.Font("Century Gothic", 9.0!)
        Me.network3.FontColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.network3.Location = New System.Drawing.Point(3, 817)
        Me.network3.Name = "network3"
        Me.network3.Size = New System.Drawing.Size(200, 22)
        Me.network3.TabIndex = 48
        Me.network3.Text = "Repair Internet Connection"
        '
        'chk15
        '
        Me.chk15.BaseColour = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(13, Byte), Integer), CType(CType(58, Byte), Integer))
        Me.chk15.BorderColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.chk15.Checked = False
        Me.chk15.CheckedColour = System.Drawing.Color.FromArgb(CType(CType(231, Byte), Integer), CType(CType(76, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.chk15.Cursor = System.Windows.Forms.Cursors.Hand
        Me.chk15.Font = New System.Drawing.Font("Century Gothic", 9.0!)
        Me.chk15.FontColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.chk15.Location = New System.Drawing.Point(3, 845)
        Me.chk15.Name = "chk15"
        Me.chk15.Size = New System.Drawing.Size(184, 22)
        Me.chk15.TabIndex = 37
        Me.chk15.Text = "Connection Sharing"
        '
        'Panel6
        '
        Me.Panel6.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(13, Byte), Integer), CType(CType(58, Byte), Integer))
        Me.Panel6.Controls.Add(Me.PictureBox4)
        Me.Panel6.Controls.Add(Me.Label6)
        Me.Panel6.Cursor = System.Windows.Forms.Cursors.Arrow
        Me.Panel6.Location = New System.Drawing.Point(3, 873)
        Me.Panel6.Name = "Panel6"
        Me.Panel6.Size = New System.Drawing.Size(200, 32)
        Me.Panel6.TabIndex = 44
        '
        'PictureBox4
        '
        Me.PictureBox4.Cursor = System.Windows.Forms.Cursors.Arrow
        Me.PictureBox4.Image = Global.Winix___MemoryCleaner.My.Resources.Resources.game_controller_icon
        Me.PictureBox4.Location = New System.Drawing.Point(10, 3)
        Me.PictureBox4.Name = "PictureBox4"
        Me.PictureBox4.Size = New System.Drawing.Size(25, 25)
        Me.PictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox4.TabIndex = 1
        Me.PictureBox4.TabStop = False
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Cursor = System.Windows.Forms.Cursors.Arrow
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
        Me.Label6.ForeColor = System.Drawing.Color.White
        Me.Label6.Location = New System.Drawing.Point(40, 6)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(48, 17)
        Me.Label6.TabIndex = 0
        Me.Label6.Text = "GAME"
        '
        'CheckBox6
        '
        Me.CheckBox6.BaseColour = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(13, Byte), Integer), CType(CType(58, Byte), Integer))
        Me.CheckBox6.BorderColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.CheckBox6.Checked = False
        Me.CheckBox6.CheckedColour = System.Drawing.Color.FromArgb(CType(CType(231, Byte), Integer), CType(CType(76, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.CheckBox6.Cursor = System.Windows.Forms.Cursors.Hand
        Me.CheckBox6.FontColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.CheckBox6.Location = New System.Drawing.Point(3, 911)
        Me.CheckBox6.Name = "CheckBox6"
        Me.CheckBox6.Size = New System.Drawing.Size(184, 22)
        Me.CheckBox6.TabIndex = 26
        Me.CheckBox6.Text = "Speed Up Keyboard Response"
        '
        'CheckBox5
        '
        Me.CheckBox5.BaseColour = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(13, Byte), Integer), CType(CType(58, Byte), Integer))
        Me.CheckBox5.BorderColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.CheckBox5.Checked = True
        Me.CheckBox5.CheckedColour = System.Drawing.Color.FromArgb(CType(CType(231, Byte), Integer), CType(CType(76, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.CheckBox5.Cursor = System.Windows.Forms.Cursors.Hand
        Me.CheckBox5.FontColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.CheckBox5.Location = New System.Drawing.Point(3, 939)
        Me.CheckBox5.Name = "CheckBox5"
        Me.CheckBox5.Size = New System.Drawing.Size(184, 22)
        Me.CheckBox5.TabIndex = 30
        Me.CheckBox5.Text = "Decrease Ping Games"
        '
        'Panel7
        '
        Me.Panel7.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(13, Byte), Integer), CType(CType(58, Byte), Integer))
        Me.Panel7.Controls.Add(Me.PictureBox5)
        Me.Panel7.Controls.Add(Me.Label7)
        Me.Panel7.Cursor = System.Windows.Forms.Cursors.Arrow
        Me.Panel7.Location = New System.Drawing.Point(3, 967)
        Me.Panel7.Name = "Panel7"
        Me.Panel7.Size = New System.Drawing.Size(200, 32)
        Me.Panel7.TabIndex = 45
        '
        'PictureBox5
        '
        Me.PictureBox5.Cursor = System.Windows.Forms.Cursors.Arrow
        Me.PictureBox5.Image = Global.Winix___MemoryCleaner.My.Resources.Resources.folder_icon
        Me.PictureBox5.Location = New System.Drawing.Point(10, 3)
        Me.PictureBox5.Name = "PictureBox5"
        Me.PictureBox5.Size = New System.Drawing.Size(25, 25)
        Me.PictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox5.TabIndex = 1
        Me.PictureBox5.TabStop = False
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Cursor = System.Windows.Forms.Cursors.Arrow
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
        Me.Label7.ForeColor = System.Drawing.Color.White
        Me.Label7.Location = New System.Drawing.Point(40, 6)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(64, 17)
        Me.Label7.TabIndex = 0
        Me.Label7.Text = "FOLDER"
        '
        'limparlixeira
        '
        Me.limparlixeira.BaseColour = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(13, Byte), Integer), CType(CType(58, Byte), Integer))
        Me.limparlixeira.BorderColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.limparlixeira.Checked = False
        Me.limparlixeira.CheckedColour = System.Drawing.Color.FromArgb(CType(CType(231, Byte), Integer), CType(CType(76, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.limparlixeira.Cursor = System.Windows.Forms.Cursors.Hand
        Me.limparlixeira.FontColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.limparlixeira.Location = New System.Drawing.Point(3, 1005)
        Me.limparlixeira.Name = "limparlixeira"
        Me.limparlixeira.Size = New System.Drawing.Size(176, 22)
        Me.limparlixeira.TabIndex = 49
        Me.limparlixeira.Text = "Clean Windows Recycle Bin"
        Me.limparlixeira.Visible = False
        '
        'CheckBox10
        '
        Me.CheckBox10.BaseColour = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(13, Byte), Integer), CType(CType(58, Byte), Integer))
        Me.CheckBox10.BorderColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.CheckBox10.Checked = True
        Me.CheckBox10.CheckedColour = System.Drawing.Color.FromArgb(CType(CType(231, Byte), Integer), CType(CType(76, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.CheckBox10.Cursor = System.Windows.Forms.Cursors.Hand
        Me.CheckBox10.FontColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.CheckBox10.Location = New System.Drawing.Point(3, 1033)
        Me.CheckBox10.Name = "CheckBox10"
        Me.CheckBox10.Size = New System.Drawing.Size(164, 22)
        Me.CheckBox10.TabIndex = 33
        Me.CheckBox10.Text = "Clear Temp Folder"
        '
        'CheckBox11
        '
        Me.CheckBox11.BaseColour = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(13, Byte), Integer), CType(CType(58, Byte), Integer))
        Me.CheckBox11.BorderColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.CheckBox11.Checked = True
        Me.CheckBox11.CheckedColour = System.Drawing.Color.FromArgb(CType(CType(231, Byte), Integer), CType(CType(76, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.CheckBox11.Cursor = System.Windows.Forms.Cursors.Hand
        Me.CheckBox11.FontColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.CheckBox11.Location = New System.Drawing.Point(3, 1061)
        Me.CheckBox11.Name = "CheckBox11"
        Me.CheckBox11.Size = New System.Drawing.Size(164, 22)
        Me.CheckBox11.TabIndex = 34
        Me.CheckBox11.Text = "Clear Prefetch Folder"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 17.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel)
        Me.Label2.ForeColor = System.Drawing.Color.White
        Me.Label2.Location = New System.Drawing.Point(12, 7)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(171, 20)
        Me.Label2.TabIndex = 4
        Me.Label2.Text = "BOOST WINDOWS"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.FromArgb(CType(CType(1, Byte), Integer), CType(CType(3, Byte), Integer), CType(CType(47, Byte), Integer))
        Me.Button1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Button1.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(1, Byte), Integer), CType(CType(3, Byte), Integer), CType(CType(47, Byte), Integer))
        Me.Button1.FlatAppearance.BorderSize = 0
        Me.Button1.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(13, Byte), Integer), CType(CType(58, Byte), Integer))
        Me.Button1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(1, Byte), Integer), CType(CType(3, Byte), Integer), CType(CType(47, Byte), Integer))
        Me.Button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button1.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel)
        Me.Button1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(231, Byte), Integer), CType(CType(76, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.Button1.Image = Global.Winix___MemoryCleaner.My.Resources.Resources.Rocket_Button_Icon
        Me.Button1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button1.Location = New System.Drawing.Point(12, 357)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(160, 45)
        Me.Button1.TabIndex = 4
        Me.Button1.Text = "RAM BOOSTER"
        Me.Button1.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Button1.UseVisualStyleBackColor = False
        '
        'Button2
        '
        Me.Button2.BackColor = System.Drawing.Color.FromArgb(CType(CType(1, Byte), Integer), CType(CType(3, Byte), Integer), CType(CType(47, Byte), Integer))
        Me.Button2.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Button2.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(1, Byte), Integer), CType(CType(3, Byte), Integer), CType(CType(47, Byte), Integer))
        Me.Button2.FlatAppearance.BorderSize = 0
        Me.Button2.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(13, Byte), Integer), CType(CType(58, Byte), Integer))
        Me.Button2.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(1, Byte), Integer), CType(CType(3, Byte), Integer), CType(CType(47, Byte), Integer))
        Me.Button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button2.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel)
        Me.Button2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(231, Byte), Integer), CType(CType(76, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.Button2.Image = Global.Winix___MemoryCleaner.My.Resources.Resources.Windows_Button_Icon
        Me.Button2.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button2.Location = New System.Drawing.Point(183, 357)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(234, 45)
        Me.Button2.TabIndex = 5
        Me.Button2.Text = "SPEED UP WINDOWS"
        Me.Button2.UseVisualStyleBackColor = False
        '
        'TimerCPU
        '
        Me.TimerCPU.Interval = 1500
        '
        'TimerRAM
        '
        '
        'TimerReleaseMemory
        '
        Me.TimerReleaseMemory.Enabled = True
        Me.TimerReleaseMemory.Interval = 4000
        '
        'lwProcs
        '
        Me.lwProcs.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.coluna5, Me.ColumnHeader1, Me.ColumnHeader2, Me.ColumnHeader3, Me.ColumnHeader4})
        Me.lwProcs.Location = New System.Drawing.Point(421, 374)
        Me.lwProcs.Name = "lwProcs"
        Me.lwProcs.Size = New System.Drawing.Size(23, 21)
        Me.lwProcs.TabIndex = 25
        Me.lwProcs.UseCompatibleStateImageBehavior = False
        Me.lwProcs.View = System.Windows.Forms.View.Details
        Me.lwProcs.Visible = False
        '
        'coluna5
        '
        Me.coluna5.DisplayIndex = 4
        Me.coluna5.Text = "ID"
        '
        'ColumnHeader1
        '
        Me.ColumnHeader1.DisplayIndex = 0
        Me.ColumnHeader1.Text = "Processos"
        '
        'ColumnHeader2
        '
        Me.ColumnHeader2.DisplayIndex = 1
        Me.ColumnHeader2.Text = "Caption"
        '
        'ColumnHeader3
        '
        Me.ColumnHeader3.DisplayIndex = 2
        Me.ColumnHeader3.Text = "Memoria"
        '
        'ColumnHeader4
        '
        Me.ColumnHeader4.DisplayIndex = 3
        Me.ColumnHeader4.Text = "Diferencial"
        '
        'pc_CPU
        '
        Me.pc_CPU.CategoryName = "Processor"
        Me.pc_CPU.CounterName = "% Processor Time"
        Me.pc_CPU.InstanceName = "_Total"
        '
        'imgIcons
        '
        Me.imgIcons.ImageStream = CType(resources.GetObject("imgIcons.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.imgIcons.TransparentColor = System.Drawing.Color.Transparent
        Me.imgIcons.Images.SetKeyName(0, "userLogo.png")
        '
        'BackgroundWorker1
        '
        Me.BackgroundWorker1.WorkerReportsProgress = True
        Me.BackgroundWorker1.WorkerSupportsCancellation = True
        '
        'TimerSpeedWindows
        '
        Me.TimerSpeedWindows.Interval = 3000
        '
        'ListView1
        '
        Me.ListView1.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(13, Byte), Integer), CType(CType(58, Byte), Integer))
        Me.ListView1.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.ListView1.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.ColumnHeader5, Me.ColumnHeader6})
        Me.ListView1.Location = New System.Drawing.Point(378, 430)
        Me.ListView1.Name = "ListView1"
        Me.ListView1.Size = New System.Drawing.Size(30, 10)
        Me.ListView1.TabIndex = 26
        Me.ListView1.UseCompatibleStateImageBehavior = False
        Me.ListView1.Visible = False
        '
        'Timer2
        '
        Me.Timer2.Interval = 3000
        '
        'lblMemoriaDisponivel
        '
        Me.lblMemoriaDisponivel.AutoSize = True
        Me.lblMemoriaDisponivel.ForeColor = System.Drawing.Color.White
        Me.lblMemoriaDisponivel.Location = New System.Drawing.Point(188, -6)
        Me.lblMemoriaDisponivel.Name = "lblMemoriaDisponivel"
        Me.lblMemoriaDisponivel.Size = New System.Drawing.Size(25, 13)
        Me.lblMemoriaDisponivel.TabIndex = 27
        Me.lblMemoriaDisponivel.Text = "000"
        Me.lblMemoriaDisponivel.Visible = False
        '
        'panelads
        '
        Me.panelads.Cursor = System.Windows.Forms.Cursors.Hand
        Me.panelads.ErrorImage = Global.Winix___MemoryCleaner.My.Resources.Resources.UI_ADS
        Me.panelads.Image = Global.Winix___MemoryCleaner.My.Resources.Resources.Ads_NULL_WMC
        Me.panelads.InitialImage = Global.Winix___MemoryCleaner.My.Resources.Resources.UI_ADS
        Me.panelads.Location = New System.Drawing.Point(19, 409)
        Me.panelads.Name = "panelads"
        Me.panelads.Size = New System.Drawing.Size(395, 56)
        Me.panelads.TabIndex = 28
        Me.panelads.TabStop = False
        '
        'ProgressBar1
        '
        Me.ProgressBar1.BaseColour = System.Drawing.Color.FromArgb(CType(CType(1, Byte), Integer), CType(CType(3, Byte), Integer), CType(CType(47, Byte), Integer))
        Me.ProgressBar1.BorderColour = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(13, Byte), Integer), CType(CType(58, Byte), Integer))
        Me.ProgressBar1.FontColour = System.Drawing.Color.FromArgb(CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer))
        Me.ProgressBar1.Location = New System.Drawing.Point(0, -4)
        Me.ProgressBar1.Maximum = 50
        Me.ProgressBar1.Name = "ProgressBar1"
        Me.ProgressBar1.ProgressColour = System.Drawing.Color.FromArgb(CType(CType(231, Byte), Integer), CType(CType(76, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.ProgressBar1.SecondColour = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(13, Byte), Integer), CType(CType(58, Byte), Integer))
        Me.ProgressBar1.Size = New System.Drawing.Size(434, 9)
        Me.ProgressBar1.TabIndex = 24
        Me.ProgressBar1.TwoColour = False
        Me.ProgressBar1.Value = 0
        Me.ProgressBar1.Visible = False
        '
        'HomePanel
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(13, Byte), Integer), CType(CType(58, Byte), Integer))
        Me.Controls.Add(Me.panelads)
        Me.Controls.Add(Me.lblMemoriaDisponivel)
        Me.Controls.Add(Me.ListView1)
        Me.Controls.Add(Me.lwProcs)
        Me.Controls.Add(Me.ProgressBar1)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.PanelCpu)
        Me.Controls.Add(Me.PanelRam)
        Me.DoubleBuffered = True
        Me.Name = "HomePanel"
        Me.Size = New System.Drawing.Size(434, 473)
        Me.PanelRam.ResumeLayout(False)
        Me.PanelRam.PerformLayout()
        Me.Panel2.ResumeLayout(False)
        Me.PanelCpu.ResumeLayout(False)
        Me.PanelCpu.PerformLayout()
        Me.Panel3.ResumeLayout(False)
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.FlowLayoutPanel1.ResumeLayout(False)
        Me.btnWindows.ResumeLayout(False)
        Me.btnWindows.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel4.ResumeLayout(False)
        Me.Panel4.PerformLayout()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel5.ResumeLayout(False)
        Me.Panel5.PerformLayout()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel6.ResumeLayout(False)
        Me.Panel6.PerformLayout()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel7.ResumeLayout(False)
        Me.Panel7.PerformLayout()
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pc_CPU, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.panelads, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents PanelRam As Panel
    Friend WithEvents LabelRam As Label
    Friend WithEvents PanelRamLine As Panel
    Friend WithEvents PanelCpu As Panel
    Friend WithEvents Label1 As Label
    Friend WithEvents PanelCpuLine As Panel
    Friend WithEvents ramprogressbar As WinixTHEMERadialProgressBar
    Friend WithEvents pb_cpu As WinixTHEMERadialProgressBar
    Friend WithEvents Panel1 As Panel
    Friend WithEvents Label2 As Label
    Friend WithEvents Button1 As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents FlowLayoutPanel1 As FlowLayoutPanel
    Friend WithEvents CheckBox4 As WinixTHEMECheckBox
    Friend WithEvents CheckBox9 As WinixTHEMECheckBox
    Friend WithEvents CheckBox6 As WinixTHEMECheckBox
    Friend WithEvents CheckBox2 As WinixTHEMECheckBox
    Friend WithEvents CheckBox8 As WinixTHEMECheckBox
    Friend WithEvents CheckBox7 As WinixTHEMECheckBox
    Friend WithEvents CheckBox3 As WinixTHEMECheckBox
    Friend WithEvents CheckBox1 As WinixTHEMECheckBox
    Friend WithEvents CheckBox5 As WinixTHEMECheckBox
    Friend WithEvents CheckBox10 As WinixTHEMECheckBox
    Friend WithEvents CheckBox11 As WinixTHEMECheckBox
    Friend WithEvents chk2 As WinixTHEMECheckBox
    Friend WithEvents chk3 As WinixTHEMECheckBox
    Friend WithEvents chk4 As WinixTHEMECheckBox
    Friend WithEvents chk5 As WinixTHEMECheckBox
    Friend WithEvents chk7 As WinixTHEMECheckBox
    Friend WithEvents chk9 As WinixTHEMECheckBox
    Friend WithEvents chk10 As WinixTHEMECheckBox
    Friend WithEvents chk8 As WinixTHEMECheckBox
    Friend WithEvents chk6 As WinixTHEMECheckBox
    Friend WithEvents chk11 As WinixTHEMECheckBox
    Friend WithEvents chk12 As WinixTHEMECheckBox
    Friend WithEvents chk13 As WinixTHEMECheckBox
    Friend WithEvents chk14 As WinixTHEMECheckBox
    Friend WithEvents chk15 As WinixTHEMECheckBox
    Friend WithEvents chk16 As WinixTHEMECheckBox
    Friend WithEvents chk17 As WinixTHEMECheckBox
    Friend WithEvents chk18 As WinixTHEMECheckBox
    Friend WithEvents ProgressBar1 As WinixTHEMEProgressBar
    Friend WithEvents TimerCPU As Timer
    Friend WithEvents TimerRAM As Timer
    Friend WithEvents TimerReleaseMemory As Timer
    Friend WithEvents Panel2 As Panel
    Friend WithEvents lblram As Label
    Friend WithEvents Panel3 As Panel
    Friend WithEvents lblcpu As Label
    Friend WithEvents lwProcs As ListView
    Friend WithEvents coluna5 As ColumnHeader
    Friend WithEvents ColumnHeader1 As ColumnHeader
    Friend WithEvents ColumnHeader2 As ColumnHeader
    Friend WithEvents ColumnHeader3 As ColumnHeader
    Friend WithEvents ColumnHeader4 As ColumnHeader
    Friend WithEvents pc_CPU As PerformanceCounter
    Friend WithEvents imgIcons As ImageList
    Friend WithEvents BackgroundWorker1 As System.ComponentModel.BackgroundWorker
    Friend WithEvents TimerSpeedWindows As Timer
    Friend WithEvents ListView1 As ListView
    Friend WithEvents ColumnHeader5 As ColumnHeader
    Friend WithEvents ColumnHeader6 As ColumnHeader
    Friend WithEvents Timer2 As Timer
    Friend WithEvents lblMemoriaDisponivel As Label
    Friend WithEvents panelads As PictureBox
    Friend WithEvents btnWindows As Panel
    Friend WithEvents Label3 As Label
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents Panel4 As Panel
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents Label4 As Label
    Friend WithEvents Panel5 As Panel
    Friend WithEvents PictureBox3 As PictureBox
    Friend WithEvents Label5 As Label
    Friend WithEvents Panel6 As Panel
    Friend WithEvents PictureBox4 As PictureBox
    Friend WithEvents Label6 As Label
    Friend WithEvents Panel7 As Panel
    Friend WithEvents PictureBox5 As PictureBox
    Friend WithEvents Label7 As Label
    Friend WithEvents network2 As WinixTHEMECheckBox
    Friend WithEvents network1 As WinixTHEMECheckBox
    Friend WithEvents network3 As WinixTHEMECheckBox
    Friend WithEvents limparlixeira As WinixTHEMECheckBox
End Class
