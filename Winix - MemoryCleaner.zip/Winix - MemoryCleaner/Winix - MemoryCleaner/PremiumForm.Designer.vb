﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class PremiumForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(PremiumForm))
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.ListView1 = New System.Windows.Forms.ListView()
        Me.ColumnHeader1 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader2 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.FlowLayoutPanel1 = New System.Windows.Forms.FlowLayoutPanel()
        Me.CheckBox4 = New Winix___MemoryCleaner.WinixTHEMECheckBox()
        Me.CheckBox9 = New Winix___MemoryCleaner.WinixTHEMECheckBox()
        Me.CheckBox6 = New Winix___MemoryCleaner.WinixTHEMECheckBox()
        Me.CheckBox2 = New Winix___MemoryCleaner.WinixTHEMECheckBox()
        Me.CheckBox8 = New Winix___MemoryCleaner.WinixTHEMECheckBox()
        Me.CheckBox7 = New Winix___MemoryCleaner.WinixTHEMECheckBox()
        Me.CheckBox3 = New Winix___MemoryCleaner.WinixTHEMECheckBox()
        Me.CheckBox1 = New Winix___MemoryCleaner.WinixTHEMECheckBox()
        Me.CheckBox5 = New Winix___MemoryCleaner.WinixTHEMECheckBox()
        Me.CheckBox10 = New Winix___MemoryCleaner.WinixTHEMECheckBox()
        Me.CheckBox11 = New Winix___MemoryCleaner.WinixTHEMECheckBox()
        Me.chk2 = New Winix___MemoryCleaner.WinixTHEMECheckBox()
        Me.chk3 = New Winix___MemoryCleaner.WinixTHEMECheckBox()
        Me.chk4 = New Winix___MemoryCleaner.WinixTHEMECheckBox()
        Me.chk5 = New Winix___MemoryCleaner.WinixTHEMECheckBox()
        Me.chk7 = New Winix___MemoryCleaner.WinixTHEMECheckBox()
        Me.chk9 = New Winix___MemoryCleaner.WinixTHEMECheckBox()
        Me.chk10 = New Winix___MemoryCleaner.WinixTHEMECheckBox()
        Me.chk8 = New Winix___MemoryCleaner.WinixTHEMECheckBox()
        Me.chk6 = New Winix___MemoryCleaner.WinixTHEMECheckBox()
        Me.chk11 = New Winix___MemoryCleaner.WinixTHEMECheckBox()
        Me.chk12 = New Winix___MemoryCleaner.WinixTHEMECheckBox()
        Me.chk13 = New Winix___MemoryCleaner.WinixTHEMECheckBox()
        Me.chk14 = New Winix___MemoryCleaner.WinixTHEMECheckBox()
        Me.chk15 = New Winix___MemoryCleaner.WinixTHEMECheckBox()
        Me.chk16 = New Winix___MemoryCleaner.WinixTHEMECheckBox()
        Me.chk17 = New Winix___MemoryCleaner.WinixTHEMECheckBox()
        Me.chk18 = New Winix___MemoryCleaner.WinixTHEMECheckBox()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.Timer2 = New System.Windows.Forms.Timer(Me.components)
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Msgreboot1 = New Winix___MemoryCleaner.msgreboot()
        Me.Panel1.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.FlowLayoutPanel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.FromArgb(CType(CType(1, Byte), Integer), CType(CType(3, Byte), Integer), CType(CType(47, Byte), Integer))
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Controls.Add(Me.Button3)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(360, 32)
        Me.Panel1.TabIndex = 6
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Century Gothic", 10.0!)
        Me.Label1.ForeColor = System.Drawing.Color.White
        Me.Label1.Location = New System.Drawing.Point(8, 6)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(229, 19)
        Me.Label1.TabIndex = 15
        Me.Label1.Text = "Winix - MemoryCleanerPremium"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Button3
        '
        Me.Button3.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(13, Byte), Integer), CType(CType(58, Byte), Integer))
        Me.Button3.BackgroundImage = Global.Winix___MemoryCleaner.My.Resources.Resources.close
        Me.Button3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.Button3.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Button3.Dock = System.Windows.Forms.DockStyle.Right
        Me.Button3.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(1, Byte), Integer), CType(CType(3, Byte), Integer), CType(CType(47, Byte), Integer))
        Me.Button3.FlatAppearance.BorderSize = 0
        Me.Button3.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(1, Byte), Integer), CType(CType(3, Byte), Integer), CType(CType(47, Byte), Integer))
        Me.Button3.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(13, Byte), Integer), CType(CType(58, Byte), Integer))
        Me.Button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button3.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button3.ForeColor = System.Drawing.Color.White
        Me.Button3.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button3.Location = New System.Drawing.Point(330, 0)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(30, 32)
        Me.Button3.TabIndex = 14
        Me.Button3.UseVisualStyleBackColor = False
        '
        'ListView1
        '
        Me.ListView1.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(13, Byte), Integer), CType(CType(58, Byte), Integer))
        Me.ListView1.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.ListView1.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.ColumnHeader1, Me.ColumnHeader2})
        Me.ListView1.Location = New System.Drawing.Point(330, 170)
        Me.ListView1.Name = "ListView1"
        Me.ListView1.Size = New System.Drawing.Size(30, 51)
        Me.ListView1.TabIndex = 7
        Me.ListView1.UseCompatibleStateImageBehavior = False
        Me.ListView1.Visible = False
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.FlowLayoutPanel1)
        Me.GroupBox1.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Bold)
        Me.GroupBox1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(231, Byte), Integer), CType(CType(76, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.GroupBox1.Location = New System.Drawing.Point(33, 35)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(289, 312)
        Me.GroupBox1.TabIndex = 24
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Settings"
        '
        'FlowLayoutPanel1
        '
        Me.FlowLayoutPanel1.AutoScroll = True
        Me.FlowLayoutPanel1.Controls.Add(Me.CheckBox4)
        Me.FlowLayoutPanel1.Controls.Add(Me.CheckBox9)
        Me.FlowLayoutPanel1.Controls.Add(Me.CheckBox6)
        Me.FlowLayoutPanel1.Controls.Add(Me.CheckBox2)
        Me.FlowLayoutPanel1.Controls.Add(Me.CheckBox8)
        Me.FlowLayoutPanel1.Controls.Add(Me.CheckBox7)
        Me.FlowLayoutPanel1.Controls.Add(Me.CheckBox3)
        Me.FlowLayoutPanel1.Controls.Add(Me.CheckBox1)
        Me.FlowLayoutPanel1.Controls.Add(Me.CheckBox5)
        Me.FlowLayoutPanel1.Controls.Add(Me.CheckBox10)
        Me.FlowLayoutPanel1.Controls.Add(Me.CheckBox11)
        Me.FlowLayoutPanel1.Controls.Add(Me.chk2)
        Me.FlowLayoutPanel1.Controls.Add(Me.chk3)
        Me.FlowLayoutPanel1.Controls.Add(Me.chk4)
        Me.FlowLayoutPanel1.Controls.Add(Me.chk5)
        Me.FlowLayoutPanel1.Controls.Add(Me.chk7)
        Me.FlowLayoutPanel1.Controls.Add(Me.chk9)
        Me.FlowLayoutPanel1.Controls.Add(Me.chk10)
        Me.FlowLayoutPanel1.Controls.Add(Me.chk8)
        Me.FlowLayoutPanel1.Controls.Add(Me.chk6)
        Me.FlowLayoutPanel1.Controls.Add(Me.chk11)
        Me.FlowLayoutPanel1.Controls.Add(Me.chk12)
        Me.FlowLayoutPanel1.Controls.Add(Me.chk13)
        Me.FlowLayoutPanel1.Controls.Add(Me.chk14)
        Me.FlowLayoutPanel1.Controls.Add(Me.chk15)
        Me.FlowLayoutPanel1.Controls.Add(Me.chk16)
        Me.FlowLayoutPanel1.Controls.Add(Me.chk17)
        Me.FlowLayoutPanel1.Controls.Add(Me.chk18)
        Me.FlowLayoutPanel1.FlowDirection = System.Windows.Forms.FlowDirection.TopDown
        Me.FlowLayoutPanel1.Location = New System.Drawing.Point(6, 21)
        Me.FlowLayoutPanel1.Name = "FlowLayoutPanel1"
        Me.FlowLayoutPanel1.Size = New System.Drawing.Size(277, 279)
        Me.FlowLayoutPanel1.TabIndex = 37
        Me.FlowLayoutPanel1.WrapContents = False
        '
        'CheckBox4
        '
        Me.CheckBox4.BaseColour = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(13, Byte), Integer), CType(CType(58, Byte), Integer))
        Me.CheckBox4.BorderColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.CheckBox4.Checked = True
        Me.CheckBox4.CheckedColour = System.Drawing.Color.FromArgb(CType(CType(231, Byte), Integer), CType(CType(76, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.CheckBox4.Cursor = System.Windows.Forms.Cursors.Hand
        Me.CheckBox4.FontColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.CheckBox4.Location = New System.Drawing.Point(3, 3)
        Me.CheckBox4.Name = "CheckBox4"
        Me.CheckBox4.Size = New System.Drawing.Size(184, 22)
        Me.CheckBox4.TabIndex = 24
        Me.CheckBox4.Text = "Speed Up Windows"
        '
        'CheckBox9
        '
        Me.CheckBox9.BaseColour = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(13, Byte), Integer), CType(CType(58, Byte), Integer))
        Me.CheckBox9.BorderColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.CheckBox9.Checked = False
        Me.CheckBox9.CheckedColour = System.Drawing.Color.FromArgb(CType(CType(231, Byte), Integer), CType(CType(76, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.CheckBox9.Cursor = System.Windows.Forms.Cursors.Hand
        Me.CheckBox9.FontColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.CheckBox9.Location = New System.Drawing.Point(3, 31)
        Me.CheckBox9.Name = "CheckBox9"
        Me.CheckBox9.Size = New System.Drawing.Size(184, 22)
        Me.CheckBox9.TabIndex = 25
        Me.CheckBox9.Text = "Speed Up : CMD"
        '
        'CheckBox6
        '
        Me.CheckBox6.BaseColour = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(13, Byte), Integer), CType(CType(58, Byte), Integer))
        Me.CheckBox6.BorderColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.CheckBox6.Checked = True
        Me.CheckBox6.CheckedColour = System.Drawing.Color.FromArgb(CType(CType(231, Byte), Integer), CType(CType(76, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.CheckBox6.Cursor = System.Windows.Forms.Cursors.Hand
        Me.CheckBox6.FontColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.CheckBox6.Location = New System.Drawing.Point(3, 59)
        Me.CheckBox6.Name = "CheckBox6"
        Me.CheckBox6.Size = New System.Drawing.Size(214, 22)
        Me.CheckBox6.TabIndex = 26
        Me.CheckBox6.Text = "Speed Up Keyboard Response"
        '
        'CheckBox2
        '
        Me.CheckBox2.BaseColour = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(13, Byte), Integer), CType(CType(58, Byte), Integer))
        Me.CheckBox2.BorderColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.CheckBox2.Checked = False
        Me.CheckBox2.CheckedColour = System.Drawing.Color.FromArgb(CType(CType(231, Byte), Integer), CType(CType(76, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.CheckBox2.Cursor = System.Windows.Forms.Cursors.Hand
        Me.CheckBox2.FontColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.CheckBox2.Location = New System.Drawing.Point(3, 87)
        Me.CheckBox2.Name = "CheckBox2"
        Me.CheckBox2.Size = New System.Drawing.Size(214, 22)
        Me.CheckBox2.TabIndex = 27
        Me.CheckBox2.Text = "Disable Aero Snap"
        '
        'CheckBox8
        '
        Me.CheckBox8.BaseColour = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(13, Byte), Integer), CType(CType(58, Byte), Integer))
        Me.CheckBox8.BorderColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.CheckBox8.Checked = False
        Me.CheckBox8.CheckedColour = System.Drawing.Color.FromArgb(CType(CType(231, Byte), Integer), CType(CType(76, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.CheckBox8.Cursor = System.Windows.Forms.Cursors.Hand
        Me.CheckBox8.FontColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.CheckBox8.Location = New System.Drawing.Point(3, 115)
        Me.CheckBox8.Name = "CheckBox8"
        Me.CheckBox8.Size = New System.Drawing.Size(214, 22)
        Me.CheckBox8.TabIndex = 28
        Me.CheckBox8.Text = "Disable Aero"
        '
        'CheckBox7
        '
        Me.CheckBox7.BaseColour = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(13, Byte), Integer), CType(CType(58, Byte), Integer))
        Me.CheckBox7.BorderColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.CheckBox7.Checked = False
        Me.CheckBox7.CheckedColour = System.Drawing.Color.FromArgb(CType(CType(231, Byte), Integer), CType(CType(76, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.CheckBox7.Cursor = System.Windows.Forms.Cursors.Hand
        Me.CheckBox7.FontColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.CheckBox7.Location = New System.Drawing.Point(3, 143)
        Me.CheckBox7.Name = "CheckBox7"
        Me.CheckBox7.Size = New System.Drawing.Size(214, 22)
        Me.CheckBox7.TabIndex = 31
        Me.CheckBox7.Text = "Transfer Rate"
        '
        'CheckBox3
        '
        Me.CheckBox3.BaseColour = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(13, Byte), Integer), CType(CType(58, Byte), Integer))
        Me.CheckBox3.BorderColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.CheckBox3.Checked = True
        Me.CheckBox3.CheckedColour = System.Drawing.Color.FromArgb(CType(CType(231, Byte), Integer), CType(CType(76, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.CheckBox3.Cursor = System.Windows.Forms.Cursors.Hand
        Me.CheckBox3.FontColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.CheckBox3.Location = New System.Drawing.Point(3, 171)
        Me.CheckBox3.Name = "CheckBox3"
        Me.CheckBox3.Size = New System.Drawing.Size(214, 22)
        Me.CheckBox3.TabIndex = 29
        Me.CheckBox3.Text = "Decrease Animation Delay"
        '
        'CheckBox1
        '
        Me.CheckBox1.BaseColour = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(13, Byte), Integer), CType(CType(58, Byte), Integer))
        Me.CheckBox1.BorderColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.CheckBox1.Checked = True
        Me.CheckBox1.CheckedColour = System.Drawing.Color.FromArgb(CType(CType(231, Byte), Integer), CType(CType(76, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.CheckBox1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.CheckBox1.FontColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.CheckBox1.Location = New System.Drawing.Point(3, 199)
        Me.CheckBox1.Name = "CheckBox1"
        Me.CheckBox1.Size = New System.Drawing.Size(214, 22)
        Me.CheckBox1.TabIndex = 32
        Me.CheckBox1.Text = "Start Programs Quickly"
        '
        'CheckBox5
        '
        Me.CheckBox5.BaseColour = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(13, Byte), Integer), CType(CType(58, Byte), Integer))
        Me.CheckBox5.BorderColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.CheckBox5.Checked = True
        Me.CheckBox5.CheckedColour = System.Drawing.Color.FromArgb(CType(CType(231, Byte), Integer), CType(CType(76, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.CheckBox5.Cursor = System.Windows.Forms.Cursors.Hand
        Me.CheckBox5.FontColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.CheckBox5.Location = New System.Drawing.Point(3, 227)
        Me.CheckBox5.Name = "CheckBox5"
        Me.CheckBox5.Size = New System.Drawing.Size(214, 22)
        Me.CheckBox5.TabIndex = 30
        Me.CheckBox5.Text = "Decrease Ping Games"
        '
        'CheckBox10
        '
        Me.CheckBox10.BaseColour = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(13, Byte), Integer), CType(CType(58, Byte), Integer))
        Me.CheckBox10.BorderColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.CheckBox10.Checked = True
        Me.CheckBox10.CheckedColour = System.Drawing.Color.FromArgb(CType(CType(231, Byte), Integer), CType(CType(76, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.CheckBox10.Cursor = System.Windows.Forms.Cursors.Hand
        Me.CheckBox10.FontColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.CheckBox10.Location = New System.Drawing.Point(3, 255)
        Me.CheckBox10.Name = "CheckBox10"
        Me.CheckBox10.Size = New System.Drawing.Size(214, 22)
        Me.CheckBox10.TabIndex = 33
        Me.CheckBox10.Text = "Clear Temp Folder"
        '
        'CheckBox11
        '
        Me.CheckBox11.BaseColour = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(13, Byte), Integer), CType(CType(58, Byte), Integer))
        Me.CheckBox11.BorderColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.CheckBox11.Checked = True
        Me.CheckBox11.CheckedColour = System.Drawing.Color.FromArgb(CType(CType(231, Byte), Integer), CType(CType(76, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.CheckBox11.Cursor = System.Windows.Forms.Cursors.Hand
        Me.CheckBox11.FontColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.CheckBox11.Location = New System.Drawing.Point(3, 283)
        Me.CheckBox11.Name = "CheckBox11"
        Me.CheckBox11.Size = New System.Drawing.Size(214, 22)
        Me.CheckBox11.TabIndex = 34
        Me.CheckBox11.Text = "Clear Prefetch Folder"
        '
        'chk2
        '
        Me.chk2.BaseColour = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(13, Byte), Integer), CType(CType(58, Byte), Integer))
        Me.chk2.BorderColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.chk2.Checked = False
        Me.chk2.CheckedColour = System.Drawing.Color.FromArgb(CType(CType(231, Byte), Integer), CType(CType(76, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.chk2.Cursor = System.Windows.Forms.Cursors.Hand
        Me.chk2.Font = New System.Drawing.Font("Century Gothic", 9.0!)
        Me.chk2.FontColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.chk2.Location = New System.Drawing.Point(3, 311)
        Me.chk2.Name = "chk2"
        Me.chk2.Size = New System.Drawing.Size(184, 22)
        Me.chk2.TabIndex = 24
        Me.chk2.Text = "Windows Defender"
        '
        'chk3
        '
        Me.chk3.BaseColour = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(13, Byte), Integer), CType(CType(58, Byte), Integer))
        Me.chk3.BorderColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.chk3.Checked = False
        Me.chk3.CheckedColour = System.Drawing.Color.FromArgb(CType(CType(231, Byte), Integer), CType(CType(76, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.chk3.Cursor = System.Windows.Forms.Cursors.Hand
        Me.chk3.Font = New System.Drawing.Font("Century Gothic", 9.0!)
        Me.chk3.FontColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.chk3.Location = New System.Drawing.Point(3, 339)
        Me.chk3.Name = "chk3"
        Me.chk3.Size = New System.Drawing.Size(184, 22)
        Me.chk3.TabIndex = 25
        Me.chk3.Text = "Windows Search"
        '
        'chk4
        '
        Me.chk4.BaseColour = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(13, Byte), Integer), CType(CType(58, Byte), Integer))
        Me.chk4.BorderColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.chk4.Checked = False
        Me.chk4.CheckedColour = System.Drawing.Color.FromArgb(CType(CType(231, Byte), Integer), CType(CType(76, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.chk4.Cursor = System.Windows.Forms.Cursors.Hand
        Me.chk4.Font = New System.Drawing.Font("Century Gothic", 9.0!)
        Me.chk4.FontColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.chk4.Location = New System.Drawing.Point(3, 367)
        Me.chk4.Name = "chk4"
        Me.chk4.Size = New System.Drawing.Size(214, 22)
        Me.chk4.TabIndex = 26
        Me.chk4.Text = "Windows Update"
        '
        'chk5
        '
        Me.chk5.BaseColour = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(13, Byte), Integer), CType(CType(58, Byte), Integer))
        Me.chk5.BorderColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.chk5.Checked = False
        Me.chk5.CheckedColour = System.Drawing.Color.FromArgb(CType(CType(231, Byte), Integer), CType(CType(76, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.chk5.Cursor = System.Windows.Forms.Cursors.Hand
        Me.chk5.Font = New System.Drawing.Font("Century Gothic", 9.0!)
        Me.chk5.FontColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.chk5.Location = New System.Drawing.Point(3, 395)
        Me.chk5.Name = "chk5"
        Me.chk5.Size = New System.Drawing.Size(214, 22)
        Me.chk5.TabIndex = 27
        Me.chk5.Text = "Print Spooler"
        '
        'chk7
        '
        Me.chk7.BaseColour = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(13, Byte), Integer), CType(CType(58, Byte), Integer))
        Me.chk7.BorderColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.chk7.Checked = False
        Me.chk7.CheckedColour = System.Drawing.Color.FromArgb(CType(CType(231, Byte), Integer), CType(CType(76, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.chk7.Cursor = System.Windows.Forms.Cursors.Hand
        Me.chk7.Font = New System.Drawing.Font("Century Gothic", 9.0!)
        Me.chk7.FontColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.chk7.Location = New System.Drawing.Point(3, 423)
        Me.chk7.Name = "chk7"
        Me.chk7.Size = New System.Drawing.Size(214, 22)
        Me.chk7.TabIndex = 29
        Me.chk7.Text = "Security Center"
        '
        'chk9
        '
        Me.chk9.BaseColour = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(13, Byte), Integer), CType(CType(58, Byte), Integer))
        Me.chk9.BorderColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.chk9.Checked = False
        Me.chk9.CheckedColour = System.Drawing.Color.FromArgb(CType(CType(231, Byte), Integer), CType(CType(76, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.chk9.Cursor = System.Windows.Forms.Cursors.Hand
        Me.chk9.Font = New System.Drawing.Font("Century Gothic", 9.0!)
        Me.chk9.FontColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.chk9.Location = New System.Drawing.Point(3, 451)
        Me.chk9.Name = "chk9"
        Me.chk9.Size = New System.Drawing.Size(214, 22)
        Me.chk9.TabIndex = 31
        Me.chk9.Text = "Adaptive Brightness"
        '
        'chk10
        '
        Me.chk10.BaseColour = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(13, Byte), Integer), CType(CType(58, Byte), Integer))
        Me.chk10.BorderColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.chk10.Checked = False
        Me.chk10.CheckedColour = System.Drawing.Color.FromArgb(CType(CType(231, Byte), Integer), CType(CType(76, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.chk10.Cursor = System.Windows.Forms.Cursors.Hand
        Me.chk10.Font = New System.Drawing.Font("Century Gothic", 9.0!)
        Me.chk10.FontColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.chk10.Location = New System.Drawing.Point(3, 479)
        Me.chk10.Name = "chk10"
        Me.chk10.Size = New System.Drawing.Size(214, 22)
        Me.chk10.TabIndex = 32
        Me.chk10.Text = "Routing and Remote Access"
        '
        'chk8
        '
        Me.chk8.BaseColour = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(13, Byte), Integer), CType(CType(58, Byte), Integer))
        Me.chk8.BorderColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.chk8.Checked = False
        Me.chk8.CheckedColour = System.Drawing.Color.FromArgb(CType(CType(231, Byte), Integer), CType(CType(76, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.chk8.Cursor = System.Windows.Forms.Cursors.Hand
        Me.chk8.Font = New System.Drawing.Font("Century Gothic", 9.0!)
        Me.chk8.FontColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.chk8.Location = New System.Drawing.Point(3, 507)
        Me.chk8.Name = "chk8"
        Me.chk8.Size = New System.Drawing.Size(214, 22)
        Me.chk8.TabIndex = 30
        Me.chk8.Text = "Secondary Logon"
        '
        'chk6
        '
        Me.chk6.BaseColour = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(13, Byte), Integer), CType(CType(58, Byte), Integer))
        Me.chk6.BorderColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.chk6.Checked = False
        Me.chk6.CheckedColour = System.Drawing.Color.FromArgb(CType(CType(231, Byte), Integer), CType(CType(76, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.chk6.Cursor = System.Windows.Forms.Cursors.Hand
        Me.chk6.Font = New System.Drawing.Font("Century Gothic", 9.0!)
        Me.chk6.FontColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.chk6.Location = New System.Drawing.Point(3, 535)
        Me.chk6.Name = "chk6"
        Me.chk6.Size = New System.Drawing.Size(214, 22)
        Me.chk6.TabIndex = 28
        Me.chk6.Text = "Smart Card"
        '
        'chk11
        '
        Me.chk11.BaseColour = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(13, Byte), Integer), CType(CType(58, Byte), Integer))
        Me.chk11.BorderColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.chk11.Checked = False
        Me.chk11.CheckedColour = System.Drawing.Color.FromArgb(CType(CType(231, Byte), Integer), CType(CType(76, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.chk11.Cursor = System.Windows.Forms.Cursors.Hand
        Me.chk11.Font = New System.Drawing.Font("Century Gothic", 9.0!)
        Me.chk11.FontColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.chk11.Location = New System.Drawing.Point(3, 563)
        Me.chk11.Name = "chk11"
        Me.chk11.Size = New System.Drawing.Size(214, 22)
        Me.chk11.TabIndex = 33
        Me.chk11.Text = "Encryption Services"
        '
        'chk12
        '
        Me.chk12.BaseColour = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(13, Byte), Integer), CType(CType(58, Byte), Integer))
        Me.chk12.BorderColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.chk12.Checked = False
        Me.chk12.CheckedColour = System.Drawing.Color.FromArgb(CType(CType(231, Byte), Integer), CType(CType(76, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.chk12.Cursor = System.Windows.Forms.Cursors.Hand
        Me.chk12.Font = New System.Drawing.Font("Century Gothic", 9.0!)
        Me.chk12.FontColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.chk12.Location = New System.Drawing.Point(3, 591)
        Me.chk12.Name = "chk12"
        Me.chk12.Size = New System.Drawing.Size(214, 22)
        Me.chk12.TabIndex = 34
        Me.chk12.Text = "Windows Error Reporting Services"
        '
        'chk13
        '
        Me.chk13.BaseColour = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(13, Byte), Integer), CType(CType(58, Byte), Integer))
        Me.chk13.BorderColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.chk13.Checked = False
        Me.chk13.CheckedColour = System.Drawing.Color.FromArgb(CType(CType(231, Byte), Integer), CType(CType(76, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.chk13.Cursor = System.Windows.Forms.Cursors.Hand
        Me.chk13.Font = New System.Drawing.Font("Century Gothic", 9.0!)
        Me.chk13.FontColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.chk13.Location = New System.Drawing.Point(3, 619)
        Me.chk13.Name = "chk13"
        Me.chk13.Size = New System.Drawing.Size(184, 22)
        Me.chk13.TabIndex = 35
        Me.chk13.Text = "Windows Firewall"
        '
        'chk14
        '
        Me.chk14.BaseColour = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(13, Byte), Integer), CType(CType(58, Byte), Integer))
        Me.chk14.BorderColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.chk14.Checked = False
        Me.chk14.CheckedColour = System.Drawing.Color.FromArgb(CType(CType(231, Byte), Integer), CType(CType(76, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.chk14.Cursor = System.Windows.Forms.Cursors.Hand
        Me.chk14.Font = New System.Drawing.Font("Century Gothic", 9.0!)
        Me.chk14.FontColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.chk14.Location = New System.Drawing.Point(3, 647)
        Me.chk14.Name = "chk14"
        Me.chk14.Size = New System.Drawing.Size(184, 22)
        Me.chk14.TabIndex = 36
        Me.chk14.Text = "Windows Image Acquisition"
        '
        'chk15
        '
        Me.chk15.BaseColour = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(13, Byte), Integer), CType(CType(58, Byte), Integer))
        Me.chk15.BorderColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.chk15.Checked = False
        Me.chk15.CheckedColour = System.Drawing.Color.FromArgb(CType(CType(231, Byte), Integer), CType(CType(76, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.chk15.Cursor = System.Windows.Forms.Cursors.Hand
        Me.chk15.Font = New System.Drawing.Font("Century Gothic", 9.0!)
        Me.chk15.FontColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.chk15.Location = New System.Drawing.Point(3, 675)
        Me.chk15.Name = "chk15"
        Me.chk15.Size = New System.Drawing.Size(184, 22)
        Me.chk15.TabIndex = 37
        Me.chk15.Text = "Connection Sharing"
        '
        'chk16
        '
        Me.chk16.BaseColour = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(13, Byte), Integer), CType(CType(58, Byte), Integer))
        Me.chk16.BorderColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.chk16.Checked = False
        Me.chk16.CheckedColour = System.Drawing.Color.FromArgb(CType(CType(231, Byte), Integer), CType(CType(76, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.chk16.Cursor = System.Windows.Forms.Cursors.Hand
        Me.chk16.Font = New System.Drawing.Font("Century Gothic", 9.0!)
        Me.chk16.FontColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.chk16.Location = New System.Drawing.Point(3, 703)
        Me.chk16.Name = "chk16"
        Me.chk16.Size = New System.Drawing.Size(192, 22)
        Me.chk16.TabIndex = 38
        Me.chk16.Text = "Windows Biometrics Service"
        '
        'chk17
        '
        Me.chk17.BaseColour = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(13, Byte), Integer), CType(CType(58, Byte), Integer))
        Me.chk17.BorderColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.chk17.Checked = False
        Me.chk17.CheckedColour = System.Drawing.Color.FromArgb(CType(CType(231, Byte), Integer), CType(CType(76, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.chk17.Cursor = System.Windows.Forms.Cursors.Hand
        Me.chk17.Font = New System.Drawing.Font("Century Gothic", 9.0!)
        Me.chk17.FontColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.chk17.Location = New System.Drawing.Point(3, 731)
        Me.chk17.Name = "chk17"
        Me.chk17.Size = New System.Drawing.Size(184, 22)
        Me.chk17.TabIndex = 39
        Me.chk17.Text = "Windows M.C Scheduler"
        '
        'chk18
        '
        Me.chk18.BaseColour = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(13, Byte), Integer), CType(CType(58, Byte), Integer))
        Me.chk18.BorderColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.chk18.Checked = False
        Me.chk18.CheckedColour = System.Drawing.Color.FromArgb(CType(CType(231, Byte), Integer), CType(CType(76, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.chk18.Cursor = System.Windows.Forms.Cursors.Hand
        Me.chk18.Font = New System.Drawing.Font("Century Gothic", 9.0!)
        Me.chk18.FontColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.chk18.Location = New System.Drawing.Point(3, 759)
        Me.chk18.Name = "chk18"
        Me.chk18.Size = New System.Drawing.Size(184, 22)
        Me.chk18.TabIndex = 40
        Me.chk18.Text = "Superfetch"
        '
        'Timer1
        '
        Me.Timer1.Interval = 3000
        '
        'Timer2
        '
        Me.Timer2.Interval = 3000
        '
        'Button2
        '
        Me.Button2.BackColor = System.Drawing.Color.FromArgb(CType(CType(1, Byte), Integer), CType(CType(3, Byte), Integer), CType(CType(47, Byte), Integer))
        Me.Button2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.Button2.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Button2.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Button2.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(13, Byte), Integer), CType(CType(58, Byte), Integer))
        Me.Button2.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(13, Byte), Integer), CType(CType(58, Byte), Integer))
        Me.Button2.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(1, Byte), Integer), CType(CType(3, Byte), Integer), CType(CType(47, Byte), Integer))
        Me.Button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button2.Font = New System.Drawing.Font("Century Gothic", 3.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Millimeter, CType(0, Byte))
        Me.Button2.ForeColor = System.Drawing.Color.White
        Me.Button2.Image = Global.Winix___MemoryCleaner.My.Resources.Resources.Registry_Editor_30px
        Me.Button2.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button2.Location = New System.Drawing.Point(0, 346)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(360, 36)
        Me.Button2.TabIndex = 26
        Me.Button2.Text = "Open Registry Restore"
        Me.Button2.UseVisualStyleBackColor = False
        Me.Button2.Visible = False
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.FromArgb(CType(CType(1, Byte), Integer), CType(CType(3, Byte), Integer), CType(CType(47, Byte), Integer))
        Me.Button1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Button1.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Button1.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(1, Byte), Integer), CType(CType(3, Byte), Integer), CType(CType(47, Byte), Integer))
        Me.Button1.FlatAppearance.BorderSize = 0
        Me.Button1.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(13, Byte), Integer), CType(CType(58, Byte), Integer))
        Me.Button1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(1, Byte), Integer), CType(CType(3, Byte), Integer), CType(CType(47, Byte), Integer))
        Me.Button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button1.Font = New System.Drawing.Font("Century Gothic", 5.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Millimeter, CType(0, Byte))
        Me.Button1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(231, Byte), Integer), CType(CType(76, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.Button1.Image = Global.Winix___MemoryCleaner.My.Resources.Resources.Windows_Client_48px
        Me.Button1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button1.Location = New System.Drawing.Point(0, 382)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(360, 47)
        Me.Button1.TabIndex = 25
        Me.Button1.Text = "Speed Up Windows"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'Msgreboot1
        '
        Me.Msgreboot1.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(13, Byte), Integer), CType(CType(58, Byte), Integer))
        Me.Msgreboot1.Location = New System.Drawing.Point(411, 137)
        Me.Msgreboot1.Name = "Msgreboot1"
        Me.Msgreboot1.Size = New System.Drawing.Size(360, 469)
        Me.Msgreboot1.TabIndex = 27
        '
        'PremiumForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(13, Byte), Integer), CType(CType(58, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(360, 429)
        Me.Controls.Add(Me.Msgreboot1)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.ListView1)
        Me.Controls.Add(Me.Panel1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "PremiumForm"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Winix - MemoryCleanerPremium"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.FlowLayoutPanel1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Panel1 As Panel
    Friend WithEvents Label1 As Label
    Friend WithEvents Button3 As Button
    Friend WithEvents ListView1 As ListView
    Friend WithEvents ColumnHeader1 As ColumnHeader
    Friend WithEvents ColumnHeader2 As ColumnHeader
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents Button1 As Button
    Friend WithEvents Timer1 As Timer
    Friend WithEvents Timer2 As Timer
    Friend WithEvents Button2 As Button
    Friend WithEvents CheckBox4 As WinixTHEMECheckBox
    Friend WithEvents CheckBox10 As WinixTHEMECheckBox
    Friend WithEvents CheckBox1 As WinixTHEMECheckBox
    Friend WithEvents CheckBox3 As WinixTHEMECheckBox
    Friend WithEvents CheckBox7 As WinixTHEMECheckBox
    Friend WithEvents CheckBox8 As WinixTHEMECheckBox
    Friend WithEvents CheckBox2 As WinixTHEMECheckBox
    Friend WithEvents CheckBox6 As WinixTHEMECheckBox
    Friend WithEvents CheckBox9 As WinixTHEMECheckBox
    Friend WithEvents CheckBox5 As WinixTHEMECheckBox
    Friend WithEvents CheckBox11 As WinixTHEMECheckBox
    Friend WithEvents chk18 As WinixTHEMECheckBox
    Friend WithEvents chk17 As WinixTHEMECheckBox
    Friend WithEvents chk16 As WinixTHEMECheckBox
    Friend WithEvents chk15 As WinixTHEMECheckBox
    Friend WithEvents chk14 As WinixTHEMECheckBox
    Friend WithEvents chk13 As WinixTHEMECheckBox
    Friend WithEvents chk12 As WinixTHEMECheckBox
    Friend WithEvents chk11 As WinixTHEMECheckBox
    Friend WithEvents chk8 As WinixTHEMECheckBox
    Friend WithEvents chk10 As WinixTHEMECheckBox
    Friend WithEvents chk7 As WinixTHEMECheckBox
    Friend WithEvents chk9 As WinixTHEMECheckBox
    Friend WithEvents chk6 As WinixTHEMECheckBox
    Friend WithEvents chk5 As WinixTHEMECheckBox
    Friend WithEvents chk4 As WinixTHEMECheckBox
    Friend WithEvents chk3 As WinixTHEMECheckBox
    Friend WithEvents chk2 As WinixTHEMECheckBox
    Friend WithEvents FlowLayoutPanel1 As FlowLayoutPanel
    Friend WithEvents Msgreboot1 As msgreboot
End Class
